library(shiny)
library(networkD3)

shinyUI(fluidPage(
  # Application title
  titlePanel("Harry Potter"),

  sidebarLayout(
    sidebarPanel(
      sliderInput("Characters",
                  "Number of characters:",
                  min = 1,
                  max = 1000,
                  value = 50),
      sliderInput("nedges",
                  "Number of maximum edges:",
                  min = 1,
                  max = 100,
                  value = 2),
      selectInput("dataset", "Choose a dataset:", 
                  choices = c("adjacencymatrix", "charactersmatrix")),
      downloadButton('downloadData', 'Download')
    ),
    

    mainPanel(
      #img(src='Image.jpg', align = "left", width = 200, height = 240),
      simpleNetworkOutput("networkPlot", width = 600, height = 600),
      plotOutput("timelinePlot", width = 600, height = 600)
    )
  )
))
