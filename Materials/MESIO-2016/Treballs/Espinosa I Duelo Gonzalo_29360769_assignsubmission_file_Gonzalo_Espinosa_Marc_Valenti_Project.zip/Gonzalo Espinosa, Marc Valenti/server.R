library(shiny)
library(ggplot2)
library(networkD3)
library(dplyr)
library(reshape2)
setwd("~/Desktop/Q2/webscrapping")

load("~/Desktop/Q2/webscrapping/withfunction.RData")

shinyServer(function(input, output) {
  
  data <- reactive({
    nova <- recortar(input$Characters,input$nedges)
    g  <- graph.adjacency(nova,weighted=TRUE)
    df <- get.data.frame(g)
    return(df)
  })
  
  output$networkPlot <- renderSimpleNetwork({
    simpleNetwork(data(),fontSize = 15,nodeColour = 1)
  })
  
  datasetInput <- reactive({
    switch(input$dataset,
           "rock" = rock,
           "pressure" = pressure,
           "cars" = cars)
  })
  
  
  output$downloadData <- downloadHandler(
   filename = function() { 
    paste(input$dataset, Sys.Date(),'.csv', sep='') 
    },
    content = function(file) {
     write.csv2(x=datasetInput(), file)
})
})
  