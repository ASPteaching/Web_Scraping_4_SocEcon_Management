## Lecture of the data
# require("rvest")
# require("wordcloud")

# Time Magazine

time <- read_html("http://search.time.com/?q=trump&site=time") %>% 
  html_nodes('div div.search-result') %>%
  html_text()
time

# The Wall-street journal

wsj <- read_html("https://www.wsj.com/search/term.html?KEYWORDS=trump") %>% 
  html_nodes('div div.headline-container') %>%
  html_text()
wsj

# The sun

sun <- read_html("https://www.thesun.co.uk/?s=trump") %>% 
  html_nodes('div div.teaser-item--search') %>%
  html_text()
sun

# The blaze

tb <- read_html("http://www.theblaze.com/?s=trump") %>% 
  html_nodes('a div.feed-bottom') %>%
  html_text()
tb

# New York Post

nyp <- read_html("http://nypost.com/?s=trump") %>% 
  html_nodes('div article') %>%
  html_text()
nyp

## Proceso de depuraci�n de la data y de extracci�n de la informaci�n

Tartas <- function(Newspapers){
  pattern1 <- '[A-z].[[:punct:]]'
  pattern2 <- '[[:punct:]].[A-z]'
  pos <- readLines("Positive-Words.txt")
  neg <- readLines("Negative-Words.txt")
  numpos <- c()
  numneg <- c()
  totalwordspos <- c()
  totalwordsneg <- c()
  totalpos <- 0
  totalneg <- 0
  for(newspaper in 1:length(Newspapers))
  {
    poswords <- c()
    negwords <- c()
    numpos[newspaper] <- 0
    numneg[newspaper] <- 0
    numposh <- 0
    numnegh <- 0
    for(header in 1:length(Newspapers[[newspaper]]))
    {
      words <- strsplit(Newspapers[[newspaper]][header], "\\s+")[[1]];
      for(j in 1:length(words))
      {
        if(gregexpr(pattern1,words[j])[[1]][1] == nchar(words[j]) - 2)
        {
          words[j] <- substring(words[j],1,nchar(words[j])-1)
        }
        if(gregexpr(pattern2,words[j])[[1]][1] == 1)
        {
          words[j] <- substring(words[j],2)
        }
        if(length(strsplit(words[j],"\n")) > 1)
        {
          words[j] <- "on"
        }
        for(w in 1:length(pos))
        {
          if(words[j] == pos[w])
          {
            numposh <- numposh + 1
            poswords[numposh] <- words[j]
            totalpos <- totalpos + 1
            totalwordspos[totalpos] <- words[j]
          }
        }
        for(w in 1:length(neg))
        {
          if(words[j] == neg[w])
          {
            numnegh <- numnegh + 1
            negwords[numnegh] <- words[j]
            totalneg <- totalneg + 1
            totalwordsneg[totalneg] <- words[j]
          }
        }
      }
    }
    numpos[newspaper] <- numposh
    numneg[newspaper] <- numnegh
  }
  # print(numpos)
  # print(numneg)
  
  freqpos <- c()
  i <- 1
  I <- length(totalwordspos)-1
  while(i <= I)
  {
    freqpos[i] <- 1
    J <- length(totalwordspos)
    j <- i+1
    while(j <= J)
    {
      if (totalwordspos[i] == totalwordspos[j]) {
        freqpos[i] <- freqpos[i] + 1
        totalwordspos <- totalwordspos[-j]
        J <- J - 1
        I <- I - 1
      }
      j <- j + 1
    }
    i <- i + 1
  }
  if (freqpos[length(freqpos)] == 1) {
    freqpos[length(freqpos)+1] <- 1
  }
  freqneg <- c()
  i <- 1
  I <- length(totalwordsneg)-1
  while(i <= I)
  {
    freqneg[i] <- 1
    J <- length(totalwordsneg)
    j <- i+1
    while(j <= J)
    {
      if (totalwordsneg[i] == totalwordsneg[j]) {
        freqneg[i] <- freqneg[i] + 1
        totalwordsneg <- totalwordsneg[-j]
        J <- J - 1
        I <- I- 1
      }
      j <- j + 1
    }
    i <- i + 1
  }
  if (freqneg[length(freqneg)] == 1) {
    freqneg[length(freqneg)+1] <- 1
  }
  
  # print(totalwordspos)
  # print(freqpos)
  # print(totalwordsneg)
  # print(freqneg)
  
  windows(width = 8, height = 6)
  par(mfrow = c(2,3))
  
  pie(c(numpos[1],numneg[1]), labels = c(numpos[1],numneg[1]), col = c(3,2))
  title(main = NULL, sub = "tb", line = 0.6, cex.sub = 1.5)
  pie(c(numpos[2],numneg[2]), labels = c(numpos[2],numneg[2]), col = c(3,2))
  title(main = NULL, sub = "time", line = 0.6, cex.sub = 1.5)
  pie(c(numpos[3],numneg[3]), labels = c(numpos[3],numneg[3]), col = c(3,2))
  title(main = NULL, sub = "sun", line = 0.6, cex.sub = 1.5)
  pie(c(numpos[4],numneg[4]), labels = c(numpos[4],numneg[4]), col = c(3,2))
  title(main = NULL, sub = "wsj", line = 0.6, cex.sub = 1.5)
  pie(c(numpos[5],numneg[5]), labels = c(numpos[5],numneg[5]), col = c(3,2))
  title(main = NULL, sub = "nyp", line = 0.6, cex.sub = 1.5)
  
  pie(c(0.2*sum(numpos),0.2*sum(numneg)), labels = c(0.2*sum(numpos),0.2*sum(numneg)), col = c(3,2))
  title(main = NULL, sub = "arithmetic mean", line = 0.6, cex.sub = 1.5)
  
  title("Positive vs. negative words in several newspapers", outer=T, line = -2.5, cex.main = 2.5)
  
  windows(width = 8, height = 6)
  par(mfrow = c(1,2))
  
  wordcloud(totalwordspos,freqpos,min.freq = 1,colors=brewer.pal(8, "Dark2"),random.color=T)
  wordcloud(totalwordsneg,freqneg,min.freq = 1,colors=brewer.pal(8, "Dark2"),random.color=T)
}

# Ejecuci�n de la funci�n

Tartas(list(nyp,sun,tb,time,wsj))

## Ejemplo Papa Francisco

# Time Magazine

time <- read_html("http://search.time.com/?q=francis&site=time") %>% 
  html_nodes('div div.search-result') %>%
  html_text()
time

# The Wall-street journal

wsj <- read_html("https://www.wsj.com/search/term.html?KEYWORDS=francis") %>% 
  html_nodes('div div.headline-container') %>%
  html_text()
wsj

# The sun

sun <- read_html("https://www.thesun.co.uk/?s=francis") %>% 
  html_nodes('div div.teaser-item--search') %>%
  html_text()
sun

# The blaze

tb <- read_html("http://www.theblaze.com/?s=francis") %>% 
  html_nodes('a div.feed-bottom') %>%
  html_text()
tb

# New York Post

nyp <- read_html("http://nypost.com/?s=francis") %>% 
  html_nodes('div article') %>%
  html_text()
nyp

Tartas(list(nyp,sun,tb,time,wsj))

## Ejemplo Obama

# Time Magazine

time <- read_html("http://search.time.com/?q=obama&site=time") %>% 
  html_nodes('div div.search-result') %>%
  html_text()
time

# The Wall-street journal

wsj <- read_html("https://www.wsj.com/search/term.html?KEYWORDS=obama") %>% 
  html_nodes('div div.headline-container') %>%
  html_text()
wsj

# The sun

sun <- read_html("https://www.thesun.co.uk/?s=obama") %>% 
  html_nodes('div div.teaser-item--search') %>%
  html_text()
sun

# The blaze

tb <- read_html("http://www.theblaze.com/?s=obama") %>% 
  html_nodes('a div.feed-bottom') %>%
  html_text()
tb

# New York Post

nyp <- read_html("http://nypost.com/?s=obama") %>% 
  html_nodes('div article') %>%
  html_text()
nyp

Tartas(list(nyp,sun,tb,time,wsj))