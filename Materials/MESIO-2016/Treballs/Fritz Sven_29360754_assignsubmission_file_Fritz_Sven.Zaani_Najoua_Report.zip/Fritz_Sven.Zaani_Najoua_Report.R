### Web Scraping Project - GIE

### Handed in by: Sven Fritz
###		            Najoua Zaani

### necessary packages #############################################################
if (!require(rvest)) install.packages("rvest", dependencies=TRUE)
if (!require(magrittr)) install.packages("magrittr")

require(rvest)
require(magrittr)

### scrapping process ##############################################################

url.cooking <- "http://allrecipes.com/"

# browse the webpage:
browse <- url.cooking %>% read_html() %>%
  html_nodes("li a") %>% html_text(trim = TRUE) 
browse

# get all hyperlinks on starting page:
temp <- url.cooking %>% read_html() %>% 
  html_nodes("a") %>% html_attr("href")

# key words:
keys <- c("salmon", "pork")

# get all hyperlinks containing key words:
ref <- list()
for(i in 1:length(keys)){
  ref[[i]] <- grep(keys[i], temp, value = TRUE)
}
ref

# list to store dataframe for every key word:
master.data <- list()

for(j in 1:length(keys)){

  #build url of subpage:
  url.interest <- paste0(url.cooking, ref[[j]][1])
  
  #scrap dishes:
  dish <- url.interest %>% read_html() %>% html_nodes(".grid-col--fixed-tiles 
                                                      .grid-col__h3--recipe-grid") %>% 
    html_text(trim = TRUE)
  
  #scrap users:
  user <- url.interest %>% read_html() %>% html_nodes(".grid-col--fixed-tiles h4") %>% 
    html_text(trim = TRUE) 
  
  #scrap articles classes as id:
  id <- url.interest %>% read_html() %>% 
    html_nodes("article") %>%
    html_attr("class") %>% na.omit()
  
  #clean id;
  id[grep("gridad", id)] <- NA
  id[grep("product", id)] <- "product_card--fixed"
  id <- grep(c("fixed"), id, value = TRUE) 
  
  #scrap statistics of interest:
  stats <- c(".grid-col__reviews", ".rating-stars")
  ratings <- list()
  for(i in 1:length(stats)){
    ratings[[i]] <- url.interest %>% read_html() %>% 
    html_nodes(stats[i])
    ratings[[i]] <- gsub("\\D", "", ratings[[i]]) %>% as.numeric() 
  }
  
  #build and clean data frame:
  data <- data.frame(id=id, user=user, dish=dish)
  data <- data[grep("^grid-col--fixed-tiles$", data$id), ]
  dummy <- grep("Recipe by ",data$user) # keep only "normal" users
  data.clean <- data[dummy, ]
  data.clean$user <- sub("Recipe by ","",data.clean$user)
  data.clean$num <- ratings[[1]]
  data.clean$stars <- ratings[[2]]
  data.clean$id <- c()
  
  master.data[[j]] <- data.clean
}

head(master.data)
