
#WEB-SCRAPPING FINAL PROJECT

#ANA ISABEL RUIZ Y MARIA SERVITJA

#------------------------------------------------------------------
#------------------------------------------------------------------

#Packages
#------------------------

# load packages
if (!require(stringr)) install.packages("stringr", dep=TRUE)
if (!require(XML)) install.packages("XML", dep=TRUE)
if (!require(maps)) install.packages("maps", dep=TRUE)

require(stringr)
require(XML)


# Getting the data
#  ------------------------------------------------------------------------

# parsing from HTML file in the web:

film<-htmlParse("https://www.filmaffinity.com/en/boxoffice.php", encoding = "UTF-8")
  

## Parsing the object
#------------------------------------------------------------
#We have obtained an object with all that is in the web page.
#Next we extract *HTML tables* from this object.


tables <- readHTMLTable(film, stringsAsFactors = FALSE)
names(tables)
# extract desired table, which is the second one
film_table <- tables[[2]]

names(film_table)
#We rename the first item of the table from # into Position
names(film_table)[1]<-"Position"
film_table


#We remove the dolar sign for:Weekend Gross and  Total Gross. 
#We also remove the commas.

#We fix the variable Weekeng Gross
WG<-sapply(film_table$`Weekend Gross`,as.character)
WG.nodol<-sapply(WG, function(x) strsplit(x, "\\$")[[1]][2])
WG.fin <- sapply(WG.nodol,function(y) str_replace_all(y, pattern=",", replacement=""))
film_table$`Weekend Gross`<-as.numeric(WG.fin)
film_table

#We fix the variable Total Gross
TG<-sapply(film_table$`Total Gross`,as.character)
TG.nodol<-sapply(TG, function(x) strsplit(x, "\\$")[[1]][2])
TG.fin <- sapply(TG.nodol,function(y) str_replace_all(y, pattern=",", replacement=""))
film_table$`Total Gross`<-as.numeric(TG.fin)
film_table


#We transform the class of some variables
#----------------------------------------

#Variable Genre -> into factor
film_table$Genre<-factor(film_table$Genre)

#Variable Position -> into numeric
film_table$Position<-as.numeric(film_table$Position)


#Variable Weeks -> into numeric
film_table$Weeks<-as.numeric(film_table$Weeks)



# Descriptive ------------------------------------------------------------

summary(film_table$Genre)


# Regression ---------------------------------------------------------------

#Regression for position of the film depending on the number of weeks and the Total Gross
mod1<- lm(film_table$Position ~ film_table$Weeks + film_table$`Total Gross`)
summary(mod1)

#Regression for  the number of weeks depending on the Total Gross
mod2<- lm(film_table$Weeks ~film_table$`Total Gross`)
summary(mod2)



# Plot of Total Gross depending on the position ---------------------------

plot(film_table$`Total Gross`~ film_table$Position, pch=16, col="blue",
     xlab="Position", ylab="Total Gross")


