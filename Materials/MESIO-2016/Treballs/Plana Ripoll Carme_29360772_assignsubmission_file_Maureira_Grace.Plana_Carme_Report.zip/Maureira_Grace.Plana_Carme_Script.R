library(rvest)
library(stringr)

###############################################################################
## Primero cargamos el itinerario elegido desde la pagina web conmochila.com ##
###############################################################################

## url del itinerario
url <- "https://www.conmochila.com/itinerario-viaje-costa-rica-21-dias-raul"

## Hacer scraping con el paquete rvest de la tabla del itinerario.
it <- read_html(url) %>%
  html_nodes('td')%>%
  html_text()
it1<-it[-seq(1,length(it),2)]

table <- data.frame(it[seq(1,length(it),2)], it1)
colnames(table) <- c("D�as", "Lugares")

## La p�gina de los itinerarios contiene un mapa, el cual tambi�n extraemos
## con "web scraping"

mapa <- read_html(url) %>%
  html_nodes('iframe')%>%
  html_attr("data-lazy-src")
mapa

## Creamos un vector donde se guardar�n todas las ciudades visitadas .
## Debido a que solo queremos la ciudad y no lo que est� en par�ntesis,
## utilizamos "regular expressions" para coger solo la ciudad

ciudades <- gsub("\\s*\\([^\\)]+\\)","",as.character(table$Lugares)) #remueve parentesis
library(stringi)
ciudades <- stri_trans_general(ciudades,"Latin-ASCII") #remueve acento
ciudades <- sub(" /.*","",ciudades) #remueve /
ciudades

###############################################################################
## Segundo, hacemos scrapping del clima de las ciudades visitadas en el      ##
## itinerario anterior, a partir de la p�gina weather.com                    ##
###############################################################################

## La p�gina weather.com utiliza c�digos internos para las ciudades consultadas,
## por lo que primero hacemos scrapping de la p�gina donde est�n los c�digos de 
## todas las ciudades del pa�s elegido, para luego obtener los c�digos de las 
## ciudades del itinerario y poder obtener los datos del clima.

url.codes <- "https://weather.codes/costa-rica/" #url codigos Costa Rica

cod.ciudad <- read_html(url.codes) %>% #Obtener los c�digos
  html_nodes('dl dt') %>%
  html_text()

nom.ciudad <- read_html(url.codes) %>% #Obtener las ciudades
  html_nodes('dl dd') %>%
  html_text()

## Con "regular expressions" eliminamos los characteres "\r" que traen 
## por defecto las ciudades 

nom.ciudad <- sub("\r","",nom.ciudad) 

## Por �ltimo se crea una tabla con los c�digos y ciudades extra�dos
tabla.codes <- data.frame(cod.ciudad[-length(cod.ciudad)],nom.ciudad)
colnames(tabla.codes) <- c("C�digo","Ciudad")
head(tabla.codes)

## Luego buscamos el c�digo de las ciudades del itinerario en la tabla
## creada anteriormente
cod.w <- numeric((length(ciudades)-1))
for (i in 1:(length(ciudades)-1)) {
  cod.w[i] <- as.character(tabla.codes[which(tabla.codes[,2] == ciudades[i])[1],1])
}
cod.w

## A continuaci�n creamos las p�ginas web de weather.com para obtener 
## el clima hist�rico del mes corriente de las ciudades del itinerario.

url.historico <- numeric((length(ciudades)-1))
for (i in 1:(length(ciudades)-1)) {
  url.historico[i] <- paste("https://weather.com/es-ES/tiempo/mensual/l/",cod.w[i],":1:CS", sep="")
}
url.historico

## Creamos el vector que guardar� la informaci�n extraida de las p�ginas
## antes obtenidas.
historico. <- rep(list(0),(length(ciudades)-1))

## Con "web scraping" extraemos la informaci�n requerida
for (i in 1:(length(ciudades)-1)) {
  clima <- read_html(url.historico[i]) %>%
    html_table('.historical-monthly', header = F)
  
  historico <- clima[[2]]
  rownames(historico) <- historico[,1]
  historico.[[i]] <- historico[,-1]
  colnames(historico.[[i]])<-c("Alto", "Bajo", "Precip.")
}
historico.

## A continuaci�n creamos las p�ginas web de weather.com para obtener 
## el clima actual de las ciudades del itinerario.

url.hoy <- numeric((length(ciudades)-1))
for (i in 1:(length(ciudades)-1)) {
  url.hoy[i] <- paste("https://weather.com/es-ES/tiempo/hoy/l/",cod.w[i],":1:CS", sep="")
}
url.hoy

## Se crea un vector para guardar los datos del clima actuales para 
## cada ciudad del itinerario

hoy. <- rep(list(0),(length(ciudades)-1))

## Con "web scraping" se extrae la informacion, y con "regular expresion" 
## se divide la informaci�n para tene un mejor entendimiento de ella

for (i in 1:(length(ciudades)-1)) { #A veces hay problemas por las cookies
  clima <- read_html(url.hoy[i]) %>%
    html_node('.today_nowcard-condition') %>%
    html_text
  
  t <- gsub("�.*", "�", clima) #Temperatura
  e <- gsub("(.+)�", "",gsub("S.*", "", clima))
  s <- gsub("M�x.*", "", gsub(".*Sensaci�n ", "", clima)) #Sensaci�n t�rmica
  mm <- str_extract(clima, "M�(.+)�") #Temperatura m�x y m�n
  uv <- gsub(".*UV ", "", clima) #�ndice UV
  
  hoy.[[i]] <- list(t,e,s,mm,uv)
}

#############################
##         RESUMEN         ##
#############################

## Ejecutar todo lo siguiente

# Itinerario:
(itinerario<-data.frame(table$D�as,ciudades))

# Mapa:  
mapa

# Temperatura actual e hist�rica del mes por ciudad
for (i in 1:(length(ciudades)-1)) {
  cat("\n======================================\n")
  cat("Ciudad: ", ciudades[i], "\n\n")
  cat("Temperatura actual: ", hoy.[[i]][[1]], "\n")
  cat("Estado: ", hoy.[[i]][[2]], "\n")
  cat("Sensaci�n t�rmica: ", hoy.[[i]][[3]], "\n")
  cat("Temperatura ", hoy.[[i]][[4]], "\n")
  cat("�ndice UV: ", hoy.[[i]][[5]], "\n")
  cat("\nHist�rico:\n")
  print(historico.[[i]])
}


###################

