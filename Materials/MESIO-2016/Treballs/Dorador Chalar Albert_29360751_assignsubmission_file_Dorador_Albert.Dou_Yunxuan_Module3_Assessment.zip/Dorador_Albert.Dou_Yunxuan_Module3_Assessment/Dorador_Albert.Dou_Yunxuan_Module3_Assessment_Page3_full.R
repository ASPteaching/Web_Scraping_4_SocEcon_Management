##########
# Page 3 #
##########

library(compiler)
enableJIT(3)
setCompilerOptions(suppressAll = TRUE)

library(twitteR)

# key <- "XXXX"          
# secret <-  "XXXX"   
# secrettk <-  "XXXX"   
# mytoken <-  "XXXX"    

# For safety reasons, we don't disclose the value of the parameters below
# and assume the user has loaded them already
setup_twitter_oauth(key, secret, mytoken, secrettk)


# A general function to extract the sentiment of any stock provided a ticker

stock.bullish = function(ticker, from, to, pos, neg, num.tweets=1e3, min.num.tweets = 10){
  require(twitteR)
  score.sentiment = function(sentences, pos.words, neg.words, .progress='none'){
    require(plyr)
    require(stringr)
    scores = laply(sentences, function(sentence, pos.words, neg.words) {
      sentence = gsub('[[:punct:]]', '', sentence)
      sentence = gsub('[[:cntrl:]]', '', sentence)
      sentence = gsub('\\d+', '', sentence)
      sentence = tolower(sentence)
      word.list = str_split(sentence, '\\s+')
      words = unlist(word.list)
      pos.matches = match(words, pos.words)
      neg.matches = match(words, neg.words)
      pos.matches = !is.na(pos.matches)
      neg.matches = !is.na(neg.matches)
      score = sum(pos.matches) - sum(neg.matches)
      return(score)
    }, pos.words, neg.words, .progress=.progress )
    scores.df = data.frame(score=scores, text=sentences)
    return(scores.df)
  }
  tweets = suppressWarnings(searchTwitter(ticker, n=num.tweets,
                         since=from, until=to, lang="en"))  # I have my own warning
  auxDF = twListToDF(tweets)
  true.num.tweets = nrow(auxDF)
  if (true.num.tweets < min.num.tweets){
    clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
    return(cat("Could only extract", true.num.tweets, "tweets for", clean.ticker, 
               "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
  }else{
    tweets.text = sapply(tweets, function(x) x$getText())
    # Replace @UserName
    tweets.text = gsub("@\\w+", "", tweets.text)
    # Remove punctuation
    tweets.text = gsub("[[:punct:]]", "", tweets.text)
    # Remove links
    tweets.text = gsub("http\\w+", "", tweets.text)
    # Remove tabs
    tweets.text = gsub("[ |\t]{2,}", "", tweets.text)
    # remove codes that are neither characters nor digits
    tweets.text=  gsub( '[^A-z0-9_]', ' ', tweets.text)
    # Set characters to lowercase
    tweets.text = tolower(tweets.text)
    # Replace blank space (rt)
    tweets.text = gsub("rt", "", tweets.text)
    # Remove blank spaces at the beginning
    tweets.text = gsub("^ ", "", tweets.text)
    # Remove blank spaces at the end
    tweets.text = gsub(" $", "", tweets.text)
  
    stock.score = score.sentiment(tweets.text, pos, neg, .progress='none')
  
    non.neutral.tweets = nrow(stock.score[stock.score[,1]!=0, ])
    
    if(non.neutral.tweets < min.num.tweets){
      clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
      return(cat("Could only extract", non.neutral.tweets, "non-neutral tweets for", clean.ticker, 
                 "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
    }else{
      return(nrow(stock.score[stock.score[,1]>0,])/non.neutral.tweets)
    } 
  }
}

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")

# Examples (careful with tickers that may have a different meaning outside stocks!)
AAPL = stock.bullish("#AAPL", '2017-05-01', '2017-05-19', pos, neg) #56.76% bullish
TWTR = stock.bullish("#TWTR", '2017-05-01', '2017-05-19', pos, neg) #71.64% bullish
SNAP = stock.bullish("#SNAP", '2017-05-01', '2017-05-19', pos, neg) #51.83% bullish
TSLA = stock.bullish("#TSLA", '2017-05-01', '2017-05-19', pos, neg) #44.19% bullish


ReapeR = function(market, pos, neg, TopCap, n.hot=3, n.cold=3,
                  from = as.character(Sys.Date()-3), to = as.character(Sys.Date()), 
                  num.tweets = 50, min.num.tweets = 10){
  require(TTR)
  stock.info = stockSymbols(market)
  tickers = stock.info[, 1]
  if (TopCap == "all"){
    n = length(tickers)
  }else{
    stock.info$MarketCap = as.double(
      sub("\\$(\\d+(\\.\\d+)?)[A-Z]?", "\\1", stock.info$MarketCap)) * 
      ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "M", 1e6,
             ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "B", 1e9, 1.0)) 
    stock.sort.ind = order(stock.info$MarketCap,na.last = NA,decreasing = TRUE)
    tickers = tickers[stock.sort.ind]
    n = TopCap
    tickers = tickers[1:n]
  }
  bullish = numeric(n)
  for(i in 1:n){
    aux = stock.bullish(paste0("#",tickers[i]), from, to, pos, neg, num.tweets, min.num.tweets)
    bullish[i] = ifelse(is.numeric(aux),aux,-1)
  }
  mask = (bullish>=0)
  bullish.clean = bullish[mask]
  n = length(bullish.clean)
  
  if(n < (n.hot+n.cold)){
    return(cat("\nRESULT:\nOnly enough non-neutral tweets for", n,
               "stocks, and you requested",n.hot,"hot stocks and",
               n.cold,"cold stocks, making a total of",(n.hot+n.cold),"stocks"))
  }
  
  tickers.clean = tickers[mask]
  
  nthmax = 1:n.hot
  h_and_h.ind = sapply(sort(bullish.clean, index.return=TRUE), '[', length(bullish.clean)-nthmax+1)
  print(h_and_h.ind)
  hot = h_and_h.ind[,1]
  hot.ind = h_and_h.ind[,2]
  hot.stocks = tickers.clean[hot.ind]
  
  nthmin = 1:n.cold
  c_and_c.ind = sapply(sort(bullish.clean, index.return=TRUE, decreasing=TRUE), '[', length(bullish.clean)-nthmin+1)
  cold = c_and_c.ind[,1]
  cold.ind = c_and_c.ind[,2]
  cold.stocks = tickers.clean[cold.ind]
  
  return(list(bullish.sentiment = bullish,
              hottest.stocks = hot.stocks,
              hottest.sentiment = hot,
              coldest.stocks = cold.stocks,
              coldest.sentiment = cold))
}

system.time({
  AMEX.all = ReapeR("AMEX",pos, neg, "all")
}) #82 min
AMEX.all
save(AMEX.all, file="AMEX_all_May20_17h.Rda")

system.time({
  AMEX.15 = ReapeR("AMEX",pos, neg, 15)
}) #4 min
AMEX.15
save(AMEX.15, file="AMEX_15_May20_18h.Rda")

system.time({
  NASDAQ.15 = ReapeR("NASDAQ",pos, neg, 15)
}) #4 min
NASDAQ.15
save(NASDAQ.15, file="NASDAQ_15_May20_18h.Rda")

system.time({
  NYSE.15 = ReapeR("NYSE",pos, neg, 15)
}) #4 min
NYSE.15
save(NYSE.15, file="NYSE_15_May20_18h.Rda")

load("AMEX_all_May20_17h.Rda")
load("NASDAQ_15_May20_18h.Rda")
load("NYSE_15_May20_18h.Rda")

AMEX.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                         Bullish = c(1,1,1,0,0,0.0667),
                         Ticker = c("RVP","RLGT","PFNX","XTNT","ENSV","UWN"))
AMEX.sum.df

NASDAQ.15.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                              Bullish = c(1,1,0.9412,0.3750,0.4783,0.5500),
                              Ticker = c("PCLN","CELG","MSFT","GOOG","SBUX","AAPL"))

NASDAQ.15.sum.df

NYSE.15.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                            Bullish = c(0.9000,0.8889,0.8667,0.2353,0.3438,0.5385),
                            Ticker = c("GE","PFE","CHL","NVS","BAC","XOM"))

NYSE.15.sum.df


# names(table(str_extract(stock.info$MarketCap,"[A-Z]")))
# gives how many unit categories there are; for the 3 markets, only B and M


# Follow those (3+3)*3 stocks for 1 week and see if the hot stocks outperformed the cold ones:


# The URL to check a stock's price in Yahoo Finance is of the form https://finance.yahoo.com/quote/ticker?p=ticker
# Moreover, the price is always on row 15 of the parsedURL using div span (using selector gadget)

# Prices on Saturday May 20, 2017:

tickers = c("RVP","RLGT","PFNX","XTNT","ENSV","UWN","PCLN","CELG","MSFT","GOOG","SBUX","AAPL",
            "GE","PFE","CHL","NVS","BAC","XOM")

getPrice = function(ticker){
  num.stocks = length(ticker) #ticker may be a vector
  require(rvest)
  price = numeric(num.stocks)
  for(i in 1:num.stocks){
    url = paste0("https://finance.yahoo.com/quote/",ticker[i], "?p=",ticker[i])
    parsedURL <- read_html(url) 
    sent   <-  parsedURL %>% 
      html_nodes('div span') %>% 
      html_text()
    price[i] = sent[15]
  }
  price = gsub(",", "", price) #remove the comma used to separate every 3 digits (if there is any)
  return(round(as.double(price),2))
}

prices_May20 = getPrice(tickers) #Prices at close of Friday May 19
save(prices_May20, file="prices_May20.Rda")
load("prices_May20.Rda")

AMEX.Bullish.prices = prices_May20[1:3]
AMEX.Bearish.prices = prices_May20[4:6]
AMEX.Bullish.Portfolio_May20 = mean(AMEX.Bullish.prices)
AMEX.Bearish.Portfolio_May20 = mean(AMEX.Bearish.prices)
AMEX.price_May20 = 2596.29

NASDAQ.Bullish.prices = prices_May20[7:9]
NASDAQ.Bearish.prices = prices_May20[10:12]
NASDAQ.Bullish.Portfolio_May20 = mean(NASDAQ.Bullish.prices)
NASDAQ.Bearish.Portfolio_May20 = mean(NASDAQ.Bearish.prices)
NASDAQ.price_May20 = 67.44

NYSE.Bullish.prices = prices_May20[13:15]
NYSE.Bearish.prices = prices_May20[16:18]
NYSE.Bullish.Portfolio_May20 = mean(NYSE.Bullish.prices)
NYSE.Bearish.Portfolio_May20 = mean(NYSE.Bearish.prices)
NYSE.price_May20 = 11542.69	


# Prices on Saturday May 27, 2017:
prices_May27 = getPrice(tickers) #Prices at close of Friday May 19
save(prices_May27, file="prices_May27.Rda")
load("prices_May27.Rda")

AMEX.Bullish.prices = prices_May27[1:3]
AMEX.Bearish.prices = prices_May27[4:6]
AMEX.Bullish.Portfolio_May27 = mean(AMEX.Bullish.prices)
AMEX.Bearish.Portfolio_May27 = mean(AMEX.Bearish.prices)
AMEX.price_May27 = 2618.7334

NASDAQ.Bullish.prices = prices_May27[7:9]
NASDAQ.Bearish.prices = prices_May27[10:12]
NASDAQ.Bullish.Portfolio_May27 = mean(NASDAQ.Bullish.prices)
NASDAQ.Bearish.Portfolio_May27 = mean(NASDAQ.Bearish.prices)
NASDAQ.price_May27 = 67.58

NYSE.Bullish.prices = prices_May27[13:15]
NYSE.Bearish.prices = prices_May27[16:18]
NYSE.Bullish.Portfolio_May27 = mean(NYSE.Bullish.prices)
NYSE.Bearish.Portfolio_May27 = mean(NYSE.Bearish.prices)
NYSE.price_May27 = 11631.87

# Compare portfolio returns
(AMEX.Bullish.Portfolio.ret = ((AMEX.Bullish.Portfolio_May27/AMEX.Bullish.Portfolio_May20)-1)*100)
(AMEX.Bearish.Portfolio.ret = ((AMEX.Bearish.Portfolio_May27/AMEX.Bearish.Portfolio_May20)-1)*100)
(AMEX.index.ret = ((AMEX.price_May27/AMEX.price_May20)-1)*100)

save(AMEX.Bullish.Portfolio.ret, file="AMEX_Bullish_Portfolio_ret.Rda")
load("AMEX_Bullish_Portfolio_ret.Rda")
save(AMEX.Bearish.Portfolio.ret, file="AMEX_Bearish_Portfolio_ret.Rda")
load("AMEX_Bearish_Portfolio_ret.Rda")
save(AMEX.index.ret, file="AMEX_index_ret.Rda")
load("AMEX_index_ret.Rda")


(NASDAQ.Bullish.Portfolio.ret = ((NASDAQ.Bullish.Portfolio_May27/NASDAQ.Bullish.Portfolio_May20)-1)*100)
(NASDAQ.Bearish.Portfolio.ret = ((NASDAQ.Bearish.Portfolio_May27/NASDAQ.Bearish.Portfolio_May20)-1)*100)
(NASDAQ.index.ret = ((NASDAQ.price_May27/NASDAQ.price_May20)-1)*100)

save(NASDAQ.Bullish.Portfolio.ret, file="NASDAQ_Bullish_Portfolio_ret.Rda")
load("NASDAQ_Bullish_Portfolio_ret.Rda")
save(NASDAQ.Bearish.Portfolio.ret, file="NASDAQ_Bearish_Portfolio_ret.Rda")
load("NASDAQ_Bearish_Portfolio_ret.Rda")
save(NASDAQ.index.ret, file="NASDAQ_index_ret.Rda")
load("NASDAQ_index_ret.Rda")


(NYSE.Bullish.Portfolio.ret = ((NYSE.Bullish.Portfolio_May27/NYSE.Bullish.Portfolio_May20)-1)*100)
(NYSE.Bearish.Portfolio.ret = ((NYSE.Bearish.Portfolio_May27/NYSE.Bearish.Portfolio_May20)-1)*100)
(NYSE.index.ret = ((NYSE.price_May27/NYSE.price_May20)-1)*100)

save(NYSE.Bullish.Portfolio.ret, file="NYSE_Bullish_Portfolio_ret.Rda")
load("NYSE_Bullish_Portfolio_ret.Rda")
save(NYSE.Bearish.Portfolio.ret, file="NYSE_Bearish_Portfolio_ret.Rda")
load("NYSE_Bearish_Portfolio_ret.Rda")
save(NYSE.index.ret, file="NYSE_index_ret.Rda")
load("NYSE_index_ret.Rda")