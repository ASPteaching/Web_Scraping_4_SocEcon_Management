##########
# Page 2 #
##########

library(compiler)
enableJIT(3)
setCompilerOptions(suppressAll = TRUE)

# Packages we will need
if (!require(twitteR)) install.packages("twitteR")
if (!require(httr)) install.packages("httr")
if (!require(tm)) install.packages("tm")
if (!require(wordcloud)) install.packages("wordcloud")
if (!require(plyr)) install.packages("plyr")
if (!require(stringr)) install.packages("stringr")

# key <- "XXXX"          
# secret <-  "XXXX"   
# secrettk <-  "XXXX"   
# mytoken <-  "XXXX"

# For safety reasons, we don't disclose the value of the parameters below
# and assume the user has loaded them already
setup_twitter_oauth(key, secret, mytoken, secrettk)

# One may skip ahead to Section 4 and load the Tweets (the file with the Tweets is attached)

#-------------------------------#
# Section 1: Stocks of interest #
#-------------------------------#
# Some of the ones that appear in a website we will use later:
# https://www.productoscotizados.com/servicios/decisiones/sentimiento-mercado

stocks = c("#S&P500", "#SP500", "#Brent", "#DAX")
m = length(stocks)
# Tweets are not case sensitive (https://zapier.com/blog/twitter-advanced-search-guide/)
# so we need not worry about this. But, we do specify 2 possible names for the S&P 500.



#-----------------------#
# Section 2: Get tweets #
#-----------------------#
today = Sys.Date()
weekb4 = today-7
no.of.tweets = 1e4 #let's get as many tweets as possible for each stock

stocksDF = data.frame()
true.num.tweets = integer(m)
for (i in 1:m){
  search.string = stocks[i]
  auxDF = twListToDF(searchTwitter(search.string, n=no.of.tweets,
                                   since=as.character(weekb4), until=as.character(today), lang="en"))
  true.num.tweets[i] = nrow(auxDF)
  stocksDF = rbind(stocksDF, auxDF)
}
true.num.tweets
colnames(stocksDF)
stocksDF[1,1]



#--------------------------------------#
# Section 3: Data cleaning using Regex #
#--------------------------------------#

# Apply battery of cleaning operations to each row of the 1st column of our dataframe
# 1.Remove @UserName
stocksDF[,1] = gsub("@\\w+", "", stocksDF[,1])
# 2. Remove punctuation
stocksDF[,1] = gsub("[[:punct:]]", "", stocksDF[,1])
# 3. Remove links
stocksDF[,1] = gsub("http\\w+", "", stocksDF[,1])
# 4. Remove tabs
stocksDF[,1] = gsub("[ |\t]{2,}", "", stocksDF[,1])
# 5. Remove codes that are neither characters nor digits
stocksDF[,1] =  gsub( '[^A-z0-9_]', ' ', stocksDF[,1])
# 6. Set characters to lowercase
stocksDF[,1] = tolower(stocksDF[,1])
# 7. Replace blank space ("rt")
stocksDF[,1] = gsub("rt", "", stocksDF[,1])
# 8. Remove blank spaces at the beginning
stocksDF[,1] = gsub("^ ", "", stocksDF[,1])
# 9. Remove blank spaces at the end
stocksDF[,1] = gsub(" $", "", stocksDF[,1])

nSP500 = (true.num.tweets[1]+true.num.tweets[2])
nBrent = true.num.tweets[3]
nDAX = true.num.tweets[4]

SP500 = stocksDF[1:nSP500, ]
Brent = stocksDF[(nSP500+1):(nSP500+nBrent), ]
DAX = stocksDF[(nSP500+nBrent+1):nrow(stocksDF), ]

save(SP500, file="SP500_tweets.Rda")
save(Brent, file="Brent_tweets.Rda")
save(DAX, file="DAX_tweets.Rda")



#-------------------------------#
# Section 4: Exploring the data #
#-------------------------------#

##################
# (A) Word Cloud #
##################

# SP500 #
if (!exists("SP500_tweets.Rda")) load("SP500_tweets.Rda")

#create corpus
SP500.corpus = Corpus(VectorSource(SP500[,1]))
#clean up by removing stop words
SP500.corpus = tm_map(SP500.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
SP500.min.frequency = round(0.25*nrow(SP500))
wordcloud(SP500.corpus, min.freq = SP500.min.frequency, scale=c(3,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)
# words plotted in decreasing frequency

# Brent #
if (!exists("Brent_tweets.Rda")) load("Brent_tweets.Rda")

#create corpus
Brent.corpus = Corpus(VectorSource(Brent[,1]))
#clean up by removing stop words
Brent.corpus = tm_map(Brent.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
Brent.min.frequency = round(0.05*nrow(Brent))
wordcloud(Brent.corpus, min.freq = Brent.min.frequency, scale=c(7,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)
# min freq is 5% in this case because more diversity in tweets

# DAX #
if (!exists("DAX_tweets.Rda")) load("DAX_tweets.Rda")

#create corpus
DAX.corpus = Corpus(VectorSource(DAX[,1]))
#clean up by removing stop words
DAX.corpus = tm_map(DAX.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
DAX.min.frequency = round(0.05*nrow(DAX))
wordcloud(DAX.corpus, min.freq = DAX.min.frequency, scale=c(7,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)


###############################
# (B) Hierarchical Clustering #
###############################

# SP500 #

SP500.tdm = TermDocumentMatrix(SP500.corpus) # high sparsity, not many inter-relationships
inspect(SP500.tdm)
findFreqTerms(SP500.tdm, lowfreq=SP500.min.frequency)
SP500.tdm =removeSparseTerms(SP500.tdm, sparse=(1-SP500.min.frequency/nrow(SP500)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

SP500.tdmscale = scale(SP500.tdm)
SP500.dist = dist(SP500.tdmscale, method = "canberra")
SP500.fit = hclust(SP500.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(SP500.fit, xlab="", sub="", col.main="salmon")


# Brent #

Brent.tdm = TermDocumentMatrix(Brent.corpus) # high sparsity, not many inter-relationships
inspect(Brent.tdm)
findFreqTerms(Brent.tdm, lowfreq=Brent.min.frequency)
Brent.tdm =removeSparseTerms(Brent.tdm, sparse=(1-(Brent.min.frequency*2)/nrow(Brent)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

Brent.tdmscale = scale(Brent.tdm)
Brent.dist = dist(Brent.tdmscale, method = "canberra")
Brent.fit = hclust(Brent.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(Brent.fit, xlab="", sub="", col.main="salmon")
rect.hclust(Brent.fit, k=4, border="salmon")


# DAX #

DAX.tdm = TermDocumentMatrix(DAX.corpus) # high sparsity, not many inter-relationships
inspect(DAX.tdm)
findFreqTerms(DAX.tdm, lowfreq=DAX.min.frequency)
DAX.tdm =removeSparseTerms(DAX.tdm, sparse=(1-DAX.min.frequency/nrow(DAX)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

DAX.tdmscale = scale(DAX.tdm)
DAX.dist = dist(DAX.tdmscale, method = "canberra")
DAX.fit = hclust(DAX.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(DAX.fit, xlab="", sub="", col.main="salmon")
rect.hclust(DAX.fit, k=5, border="salmon")



#-------------------------------#
# Section 5: Sentiment Analysis #
#-------------------------------#

# SP500 #
if (!exists("SP500_tweets.Rda")) load("SP500_tweets.Rda")

# Brent #
if (!exists("Brent_tweets.Rda")) load("Brent_tweets.Rda")

# DAX #
if (!exists("DAX_tweets.Rda")) load("DAX_tweets.Rda")

source("ScoreSentiment.R")

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")
stock.text = c(SP500[,1], Brent[,1], DAX[,1])
scores = score.sentiment(stock.text, pos, neg, .progress='none')
nd = c(nrow(SP500), nrow(Brent), nrow(DAX))
scores$Stock = factor(rep(c("S&P500", "Brent", "DAX"), nd))
scores$very.pos = as.double(scores$score >= 2)
scores$very.neg = as.double(scores$score <= -2)
numpos = sum(scores$very.pos)
numneg = sum(scores$very.neg)

head(scores)
boxplot(score~Stock, data=scores,
        xlab="Stocks", ylab="Sentiment",
        main="Boxplot: Comparing sentiment across Brent, Dax, and S&P500")

colnames(scores)

score.short = scores[,c(1,3)]
split.score = with(score.short, split(score.short, Stock))

SP500.non.neutral = nrow(split.score$`S&P500`[split.score$`S&P500`[,1]!=0,])
Brent.non.neutral = nrow(split.score$Brent[split.score$Brent[,1]!=0,])
DAX.non.neutral = nrow(split.score$DAX[split.score$DAX[,1]!=0,])

SP500.bullish=ifelse(SP500.non.neutral==0,-1,nrow(split.score$`S&P500`[split.score$`S&P500`[,1]>0,])/SP500.non.neutral)

Brent.bullish=ifelse(Brent.non.neutral==0,-1,nrow(split.score$Brent[split.score$Brent[,1]>0,])/Brent.non.neutral)

DAX.sent=ifelse(DAX.non.neutral==0,-1,nrow(split.score$DAX[split.score$DAX[,1]>0,])/DAX.non.neutral)


#---------------------------------------------#
# Twitter sentiment vs BNP clients' positions #
#---------------------------------------------#
BNP.sentiment = function(asset){
  require(rvest)
  parsedURL <- read_html('https://www.productoscotizados.com/servicios/decisiones/sentimiento-mercado') 
  sent   <-  parsedURL %>% 
    html_nodes('div div') %>% 
    html_text()
  step1 = grep("Alcista", x = sent, value = TRUE)
  asset = toupper(asset)
  num.assets = length(asset)
  asset.sent = numeric(num.assets)
  for (i in 1:num.assets){ #asset might be a character vector
    if (asset[i]=="IBEX"){
      asset.sent[i] = as.double(substr(x = step1[7], start = 8, stop = nchar(step1[7])-1))
    }
    if (asset[i]=="EURUSD"){
      asset.sent[i] = as.double(substr(x = step1[9], start = 8, stop = nchar(step1[9])-1))
    }
    if (asset[i]=="BRENT"){
      asset.sent[i] = as.double(substr(x = step1[11], start = 8, stop = nchar(step1[11])-1))
    }
    if (asset[i]=="ACCESP"){
      asset.sent[i] = as.double(substr(x = step1[13], start = 8, stop = nchar(step1[13])-1))
    }
    if (asset[i]=="ACCEUR"){
      asset.sent[i] = as.double(substr(x = step1[15], start = 8, stop = nchar(step1[15])-1))
    }
    if (asset[i]=="ACCAMER"){
      asset.sent[i] = as.double(substr(x = step1[17], start = 8, stop = nchar(step1[17])-1))
    }
    if (asset[i]=="EUROSTOXX"){
      asset.sent[i] = as.double(substr(x = step1[19], start = 8, stop = nchar(step1[19])-1))
    }
    if (asset[i]=="SP500"){
      asset.sent[i] = as.double(substr(x = step1[21], start = 8, stop = nchar(step1[21])-1))
    }
    if (asset[i]=="DAX"){
      asset.sent[i] = as.double(substr(x = step1[23], start = 8, stop = nchar(step1[23])-1))
    }
    if (asset[i]=="GOLD"){
      asset.sent[i] = as.double(substr(x = step1[25], start = 8, stop = nchar(step1[25])-1))
    } 
  }
  return(asset.sent)
}

BNP = BNP.sentiment(asset =  c("SP500", "Brent", "DAX"))
save(BNP, file = "BNP_sentiment_May23_18h.Rda")
