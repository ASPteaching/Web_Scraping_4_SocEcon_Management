#---------------------------------------------#
# ******************************************* #
# * Final Project: Stock Sentiment Analysis * #
# ******************************************* #
#---------------------------------------------#


##########
# Page 2 #
##########


library(compiler)
enableJIT(3)
setCompilerOptions(suppressAll = TRUE)

# Packages we will need
if (!require(twitteR)) install.packages("twitteR")
if (!require(httr)) install.packages("httr")
if (!require(tm)) install.packages("tm")
if (!require(wordcloud)) install.packages("wordcloud")
if (!require(plyr)) install.packages("plyr")
if (!require(stringr)) install.packages("stringr")

# key <- "XXXX"          
# secret <-  "XXXX"   
# secrettk <-  "XXXX"   
# mytoken <-  "XXXX"

# For safety reasons, we don't disclose the value of the parameters below
# and assume the user has loaded them already
setup_twitter_oauth(key, secret, mytoken, secrettk)

# One may skip ahead to Section 4 and load the Tweets (the file with the Tweets is attached)

#-------------------------------#
# Section 1: Stocks of interest #
#-------------------------------#
# Some of the ones that appear in a website we will use later:
# https://www.productoscotizados.com/servicios/decisiones/sentimiento-mercado

stocks = c("#S&P500", "#SP500", "#Brent", "#DAX")
m = length(stocks)
# Tweets are not case sensitive (https://zapier.com/blog/twitter-advanced-search-guide/)
# so we need not worry about this. But, we do specify 2 possible names for the S&P 500.



#-----------------------#
# Section 2: Get tweets #
#-----------------------#
today = Sys.Date()
weekb4 = today-7
no.of.tweets = 1e4 #let's get as many tweets as possible for each stock

stocksDF = data.frame()
true.num.tweets = integer(m)
for (i in 1:m){
  search.string = stocks[i]
  auxDF = twListToDF(searchTwitter(search.string, n=no.of.tweets,
                               since=as.character(weekb4), until=as.character(today), lang="en"))
  true.num.tweets[i] = nrow(auxDF)
  stocksDF = rbind(stocksDF, auxDF)
}
true.num.tweets
colnames(stocksDF)
stocksDF[1,1]



#--------------------------------------#
# Section 3: Data cleaning using Regex #
#--------------------------------------#

# Apply battery of cleaning operations to each row of the 1st column of our dataframe
# 1.Remove @UserName
stocksDF[,1] = gsub("@\\w+", "", stocksDF[,1])
# 2. Remove punctuation
stocksDF[,1] = gsub("[[:punct:]]", "", stocksDF[,1])
# 3. Remove links
stocksDF[,1] = gsub("http\\w+", "", stocksDF[,1])
# 4. Remove tabs
stocksDF[,1] = gsub("[ |\t]{2,}", "", stocksDF[,1])
# 5. Remove codes that are neither characters nor digits
stocksDF[,1] =  gsub( '[^A-z0-9_]', ' ', stocksDF[,1])
# 6. Set characters to lowercase
stocksDF[,1] = tolower(stocksDF[,1])
# 7. Replace blank space ("rt")
stocksDF[,1] = gsub("rt", "", stocksDF[,1])
# 8. Remove blank spaces at the beginning
stocksDF[,1] = gsub("^ ", "", stocksDF[,1])
# 9. Remove blank spaces at the end
stocksDF[,1] = gsub(" $", "", stocksDF[,1])

nSP500 = (true.num.tweets[1]+true.num.tweets[2])
nBrent = true.num.tweets[3]
nDAX = true.num.tweets[4]

SP500 = stocksDF[1:nSP500, ]
Brent = stocksDF[(nSP500+1):(nSP500+nBrent), ]
DAX = stocksDF[(nSP500+nBrent+1):nrow(stocksDF), ]

save(SP500, file="SP500_tweets.Rda")
save(Brent, file="Brent_tweets.Rda")
save(DAX, file="DAX_tweets.Rda")



#-------------------------------#
# Section 4: Exploring the data #
#-------------------------------#

##################
# (A) Word Cloud #
##################

# SP500 #
if (!exists("SP500_tweets.Rda")) load("SP500_tweets.Rda")

#create corpus
SP500.corpus = Corpus(VectorSource(SP500[,1]))
#clean up by removing stop words
SP500.corpus = tm_map(SP500.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
SP500.min.frequency = round(0.25*nrow(SP500))
wordcloud(SP500.corpus, min.freq = SP500.min.frequency, scale=c(3,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)
# words plotted in decreasing frequency

# Brent #
if (!exists("Brent_tweets.Rda")) load("Brent_tweets.Rda")

#create corpus
Brent.corpus = Corpus(VectorSource(Brent[,1]))
#clean up by removing stop words
Brent.corpus = tm_map(Brent.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
Brent.min.frequency = round(0.05*nrow(Brent))
wordcloud(Brent.corpus, min.freq = Brent.min.frequency, scale=c(7,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)
# min freq is 5% in this case because more diversity in tweets

# DAX #
if (!exists("DAX_tweets.Rda")) load("DAX_tweets.Rda")

#create corpus
DAX.corpus = Corpus(VectorSource(DAX[,1]))
#clean up by removing stop words
DAX.corpus = tm_map(DAX.corpus, function(x) removeWords(x, stopwords()))
#generate wordcloud
DAX.min.frequency = round(0.05*nrow(DAX))
wordcloud(DAX.corpus, min.freq = DAX.min.frequency, scale=c(7,0.5),
          colors=brewer.pal(8, "Dark2"),random.color= TRUE, random.order = FALSE, 
          max.words = 20)


###############################
# (B) Hierarchical Clustering #
###############################

# SP500 #

SP500.tdm = TermDocumentMatrix(SP500.corpus) # high sparsity, not many inter-relationships
inspect(SP500.tdm)
findFreqTerms(SP500.tdm, lowfreq=SP500.min.frequency)
SP500.tdm =removeSparseTerms(SP500.tdm, sparse=(1-SP500.min.frequency/nrow(SP500)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

SP500.tdmscale = scale(SP500.tdm)
SP500.dist = dist(SP500.tdmscale, method = "canberra")
SP500.fit = hclust(SP500.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(SP500.fit, xlab="", sub="", col.main="salmon")


# Brent #

Brent.tdm = TermDocumentMatrix(Brent.corpus) # high sparsity, not many inter-relationships
inspect(Brent.tdm)
findFreqTerms(Brent.tdm, lowfreq=Brent.min.frequency)
Brent.tdm =removeSparseTerms(Brent.tdm, sparse=(1-(Brent.min.frequency*2)/nrow(Brent)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

Brent.tdmscale = scale(Brent.tdm)
Brent.dist = dist(Brent.tdmscale, method = "canberra")
Brent.fit = hclust(Brent.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(Brent.fit, xlab="", sub="", col.main="salmon")
rect.hclust(Brent.fit, k=4, border="salmon")


# DAX #

DAX.tdm = TermDocumentMatrix(DAX.corpus) # high sparsity, not many inter-relationships
inspect(DAX.tdm)
findFreqTerms(DAX.tdm, lowfreq=DAX.min.frequency)
DAX.tdm =removeSparseTerms(DAX.tdm, sparse=(1-DAX.min.frequency/nrow(DAX)))
# removes the terms that don't appear in at least [100*(1-sparse)]% of tweets

DAX.tdmscale = scale(DAX.tdm)
DAX.dist = dist(DAX.tdmscale, method = "canberra")
DAX.fit = hclust(DAX.dist)

# we need to change the margins and delete some titles
par(mai=c(1,1.2,1,0.5))
plot(DAX.fit, xlab="", sub="", col.main="salmon")
rect.hclust(DAX.fit, k=5, border="salmon")



#-------------------------------#
# Section 5: Sentiment Analysis #
#-------------------------------#

# SP500 #
if (!exists("SP500_tweets.Rda")) load("SP500_tweets.Rda")

# Brent #
if (!exists("Brent_tweets.Rda")) load("Brent_tweets.Rda")

# DAX #
if (!exists("DAX_tweets.Rda")) load("DAX_tweets.Rda")

source("ScoreSentiment.R")

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")
stock.text = c(SP500[,1], Brent[,1], DAX[,1])
scores = score.sentiment(stock.text, pos, neg, .progress='none')
nd = c(nrow(SP500), nrow(Brent), nrow(DAX))
scores$Stock = factor(rep(c("S&P500", "Brent", "DAX"), nd))
scores$very.pos = as.double(scores$score >= 2)
scores$very.neg = as.double(scores$score <= -2)
numpos = sum(scores$very.pos)
numneg = sum(scores$very.neg)

head(scores)
boxplot(score~Stock, data=scores,
        xlab="Stocks", ylab="Sentiment",
        main="Boxplot: Comparing sentiment across Brent, Dax, and S&P500")

colnames(scores)

score.short = scores[,c(1,3)]
split.score = with(score.short, split(score.short, Stock))

SP500.non.neutral = nrow(split.score$`S&P500`[split.score$`S&P500`[,1]!=0,])
Brent.non.neutral = nrow(split.score$Brent[split.score$Brent[,1]!=0,])
DAX.non.neutral = nrow(split.score$DAX[split.score$DAX[,1]!=0,])

SP500.bullish=ifelse(SP500.non.neutral==0,-1,nrow(split.score$`S&P500`[split.score$`S&P500`[,1]>0,])/SP500.non.neutral)

Brent.bullish=ifelse(Brent.non.neutral==0,-1,nrow(split.score$Brent[split.score$Brent[,1]>0,])/Brent.non.neutral)

DAX.sent=ifelse(DAX.non.neutral==0,-1,nrow(split.score$DAX[split.score$DAX[,1]>0,])/DAX.non.neutral)


#---------------------------------------------#
# Twitter sentiment vs BNP clients' positions #
#---------------------------------------------#
BNP.sentiment = function(asset){
  require(rvest)
  parsedURL <- read_html('https://www.productoscotizados.com/servicios/decisiones/sentimiento-mercado') 
  sent   <-  parsedURL %>% 
    html_nodes('div div') %>% 
    html_text()
  step1 = grep("Alcista", x = sent, value = TRUE)
  asset = toupper(asset)
  num.assets = length(asset)
  asset.sent = numeric(num.assets)
  for (i in 1:num.assets){ #asset might be a character vector
    if (asset[i]=="IBEX"){
      asset.sent[i] = as.double(substr(x = step1[7], start = 8, stop = nchar(step1[7])-1))
    }
    if (asset[i]=="EURUSD"){
      asset.sent[i] = as.double(substr(x = step1[9], start = 8, stop = nchar(step1[9])-1))
    }
    if (asset[i]=="BRENT"){
      asset.sent[i] = as.double(substr(x = step1[11], start = 8, stop = nchar(step1[11])-1))
    }
    if (asset[i]=="ACCESP"){
      asset.sent[i] = as.double(substr(x = step1[13], start = 8, stop = nchar(step1[13])-1))
    }
    if (asset[i]=="ACCEUR"){
      asset.sent[i] = as.double(substr(x = step1[15], start = 8, stop = nchar(step1[15])-1))
    }
    if (asset[i]=="ACCAMER"){
      asset.sent[i] = as.double(substr(x = step1[17], start = 8, stop = nchar(step1[17])-1))
    }
    if (asset[i]=="EUROSTOXX"){
      asset.sent[i] = as.double(substr(x = step1[19], start = 8, stop = nchar(step1[19])-1))
    }
    if (asset[i]=="SP500"){
      asset.sent[i] = as.double(substr(x = step1[21], start = 8, stop = nchar(step1[21])-1))
    }
    if (asset[i]=="DAX"){
      asset.sent[i] = as.double(substr(x = step1[23], start = 8, stop = nchar(step1[23])-1))
    }
    if (asset[i]=="GOLD"){
      asset.sent[i] = as.double(substr(x = step1[25], start = 8, stop = nchar(step1[25])-1))
    } 
  }
  return(asset.sent)
}

BNP = BNP.sentiment(asset =  c("SP500", "Brent", "DAX"))
save(BNP, file = "BNP_sentiment_May23_18h.Rda")



##########
# Page 3 #
##########


# A general function to extract the sentiment of any stock provided a ticker

stock.bullish = function(ticker, from, to, pos, neg, num.tweets=1e3, min.num.tweets = 10){
  require(twitteR)
  score.sentiment = function(sentences, pos.words, neg.words, .progress='none'){
    require(plyr)
    require(stringr)
    scores = laply(sentences, function(sentence, pos.words, neg.words) {
      sentence = gsub('[[:punct:]]', '', sentence)
      sentence = gsub('[[:cntrl:]]', '', sentence)
      sentence = gsub('\\d+', '', sentence)
      sentence = tolower(sentence)
      word.list = str_split(sentence, '\\s+')
      words = unlist(word.list)
      pos.matches = match(words, pos.words)
      neg.matches = match(words, neg.words)
      pos.matches = !is.na(pos.matches)
      neg.matches = !is.na(neg.matches)
      score = sum(pos.matches) - sum(neg.matches)
      return(score)
    }, pos.words, neg.words, .progress=.progress )
    scores.df = data.frame(score=scores, text=sentences)
    return(scores.df)
  }
  tweets = suppressWarnings(searchTwitter(ticker, n=num.tweets,
                                          since=from, until=to, lang="en"))  # I have my own warning
  auxDF = twListToDF(tweets)
  true.num.tweets = nrow(auxDF)
  if (true.num.tweets < min.num.tweets){
    clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
    return(cat("Could only extract", true.num.tweets, "tweets for", clean.ticker, 
               "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
  }else{
    tweets.text = sapply(tweets, function(x) x$getText())
    # Replace @UserName
    tweets.text = gsub("@\\w+", "", tweets.text)
    # Remove punctuation
    tweets.text = gsub("[[:punct:]]", "", tweets.text)
    # Remove links
    tweets.text = gsub("http\\w+", "", tweets.text)
    # Remove tabs
    tweets.text = gsub("[ |\t]{2,}", "", tweets.text)
    # remove codes that are neither characters nor digits
    tweets.text=  gsub( '[^A-z0-9_]', ' ', tweets.text)
    # Set characters to lowercase
    tweets.text = tolower(tweets.text)
    # Replace blank space (rt)
    tweets.text = gsub("rt", "", tweets.text)
    # Remove blank spaces at the beginning
    tweets.text = gsub("^ ", "", tweets.text)
    # Remove blank spaces at the end
    tweets.text = gsub(" $", "", tweets.text)
    
    stock.score = score.sentiment(tweets.text, pos, neg, .progress='none')
    
    non.neutral.tweets = nrow(stock.score[stock.score[,1]!=0, ])
    
    if(non.neutral.tweets < min.num.tweets){
      clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
      return(cat("Could only extract", non.neutral.tweets, "non-neutral tweets for", clean.ticker, 
                 "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
    }else{
      return(nrow(stock.score[stock.score[,1]>0,])/non.neutral.tweets)
    } 
  }
}

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")

# Examples (careful with tickers that may have a different meaning outside stocks!)
AAPL = stock.bullish("#AAPL", '2017-05-01', '2017-05-19', pos, neg) #56.76% bullish
TWTR = stock.bullish("#TWTR", '2017-05-01', '2017-05-19', pos, neg) #71.64% bullish
SNAP = stock.bullish("#SNAP", '2017-05-01', '2017-05-19', pos, neg) #51.83% bullish
TSLA = stock.bullish("#TSLA", '2017-05-01', '2017-05-19', pos, neg) #44.19% bullish


ReapeR = function(market, pos, neg, TopCap, n.hot=3, n.cold=3,
                  from = as.character(Sys.Date()-3), to = as.character(Sys.Date()), 
                  num.tweets = 50, min.num.tweets = 10){
  require(TTR)
  stock.info = stockSymbols(market)
  tickers = stock.info[, 1]
  if (TopCap == "all"){
    n = length(tickers)
  }else{
    stock.info$MarketCap = as.double(
      sub("\\$(\\d+(\\.\\d+)?)[A-Z]?", "\\1", stock.info$MarketCap)) * 
      ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "M", 1e6,
             ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "B", 1e9, 1.0)) 
    stock.sort.ind = order(stock.info$MarketCap,na.last = NA,decreasing = TRUE)
    tickers = tickers[stock.sort.ind]
    n = TopCap
    tickers = tickers[1:n]
  }
  bullish = numeric(n)
  for(i in 1:n){
    aux = stock.bullish(paste0("#",tickers[i]), from, to, pos, neg, num.tweets, min.num.tweets)
    bullish[i] = ifelse(is.numeric(aux),aux,-1)
  }
  mask = (bullish>=0)
  bullish.clean = bullish[mask]
  n = length(bullish.clean)
  
  if(n < (n.hot+n.cold)){
    return(cat("\nRESULT:\nOnly enough non-neutral tweets for", n,
               "stocks, and you requested",n.hot,"hot stocks and",
               n.cold,"cold stocks, making a total of",(n.hot+n.cold),"stocks"))
  }
  
  tickers.clean = tickers[mask]
  
  nthmax = 1:n.hot
  h_and_h.ind = sapply(sort(bullish.clean, index.return=TRUE), '[', length(bullish.clean)-nthmax+1)
  print(h_and_h.ind)
  hot = h_and_h.ind[,1]
  hot.ind = h_and_h.ind[,2]
  hot.stocks = tickers.clean[hot.ind]
  
  nthmin = 1:n.cold
  c_and_c.ind = sapply(sort(bullish.clean, index.return=TRUE, decreasing=TRUE), '[', length(bullish.clean)-nthmin+1)
  cold = c_and_c.ind[,1]
  cold.ind = c_and_c.ind[,2]
  cold.stocks = tickers.clean[cold.ind]
  
  return(list(bullish.sentiment = bullish,
              hottest.stocks = hot.stocks,
              hottest.sentiment = hot,
              coldest.stocks = cold.stocks,
              coldest.sentiment = cold))
}

system.time({
  AMEX.all = ReapeR("AMEX",pos, neg, "all")
}) #82 min
AMEX.all
save(AMEX.all, file="AMEX_all_May20_17h.Rda")

system.time({
  AMEX.15 = ReapeR("AMEX",pos, neg, 15)
}) #4 min
AMEX.15
save(AMEX.15, file="AMEX_15_May20_18h.Rda")

system.time({
  NASDAQ.15 = ReapeR("NASDAQ",pos, neg, 15)
}) #4 min
NASDAQ.15
save(NASDAQ.15, file="NASDAQ_15_May20_18h.Rda")

system.time({
  NYSE.15 = ReapeR("NYSE",pos, neg, 15)
}) #4 min
NYSE.15
save(NYSE.15, file="NYSE_15_May20_18h.Rda")

load("AMEX_all_May20_17h.Rda")
load("NASDAQ_15_May20_18h.Rda")
load("NYSE_15_May20_18h.Rda")

AMEX.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                         Bullish = c(1,1,1,0,0,0.0667),
                         Ticker = c("RVP","RLGT","PFNX","XTNT","ENSV","UWN"))
AMEX.sum.df

NASDAQ.15.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                              Bullish = c(1,1,0.9412,0.3750,0.4783,0.5500),
                              Ticker = c("PCLN","CELG","MSFT","GOOG","SBUX","AAPL"))

NASDAQ.15.sum.df

NYSE.15.sum.df = data.frame(Sentiment = c("Hot_1","Hot_2","Hot_3","Cold_1","Cold_2","Cold_3"),
                            Bullish = c(0.9000,0.8889,0.8667,0.2353,0.3438,0.5385),
                            Ticker = c("GE","PFE","CHL","NVS","BAC","XOM"))

NYSE.15.sum.df


# names(table(str_extract(stock.info$MarketCap,"[A-Z]")))
# gives how many unit categories there are; for the 3 markets, only B and M


# Follow those (3+3)*3 stocks for 1 week and see if the hot stocks outperformed the cold ones:


# The URL to check a stock's price in Yahoo Finance is of the form https://finance.yahoo.com/quote/ticker?p=ticker
# Moreover, the price is always on row 15 of the parsedURL using div span (using selector gadget)

# Prices on Saturday May 20, 2017:

tickers = c("RVP","RLGT","PFNX","XTNT","ENSV","UWN","PCLN","CELG","MSFT","GOOG","SBUX","AAPL",
            "GE","PFE","CHL","NVS","BAC","XOM")

getPrice = function(ticker){
  num.stocks = length(ticker) #ticker may be a vector
  require(rvest)
  price = numeric(num.stocks)
  for(i in 1:num.stocks){
    url = paste0("https://finance.yahoo.com/quote/",ticker[i], "?p=",ticker[i])
    parsedURL <- read_html(url) 
    sent   <-  parsedURL %>% 
      html_nodes('div span') %>% 
      html_text()
    price[i] = sent[15]
  }
  price = gsub(",", "", price) #remove the comma used to separate every 3 digits (if there is any)
  return(round(as.double(price),2))
}

prices_May20 = getPrice(tickers) #Prices at close of Friday May 19
save(prices_May20, file="prices_May20.Rda")
load("prices_May20.Rda")

AMEX.Bullish.prices = prices_May20[1:3]
AMEX.Bearish.prices = prices_May20[4:6]
AMEX.Bullish.Portfolio_May20 = mean(AMEX.Bullish.prices)
AMEX.Bearish.Portfolio_May20 = mean(AMEX.Bearish.prices)
AMEX.price_May20 = 2596.29

NASDAQ.Bullish.prices = prices_May20[7:9]
NASDAQ.Bearish.prices = prices_May20[10:12]
NASDAQ.Bullish.Portfolio_May20 = mean(NASDAQ.Bullish.prices)
NASDAQ.Bearish.Portfolio_May20 = mean(NASDAQ.Bearish.prices)
NASDAQ.price_May20 = 67.44

NYSE.Bullish.prices = prices_May20[13:15]
NYSE.Bearish.prices = prices_May20[16:18]
NYSE.Bullish.Portfolio_May20 = mean(NYSE.Bullish.prices)
NYSE.Bearish.Portfolio_May20 = mean(NYSE.Bearish.prices)
NYSE.price_May20 = 11542.69	


# Prices on Saturday May 27, 2017:
prices_May27 = getPrice(tickers) #Prices at close of Friday May 19
save(prices_May27, file="prices_May27.Rda")
load("prices_May27.Rda")

AMEX.Bullish.prices = prices_May27[1:3]
AMEX.Bearish.prices = prices_May27[4:6]
AMEX.Bullish.Portfolio_May27 = mean(AMEX.Bullish.prices)
AMEX.Bearish.Portfolio_May27 = mean(AMEX.Bearish.prices)
AMEX.price_May27 = 2618.7334

NASDAQ.Bullish.prices = prices_May27[7:9]
NASDAQ.Bearish.prices = prices_May27[10:12]
NASDAQ.Bullish.Portfolio_May27 = mean(NASDAQ.Bullish.prices)
NASDAQ.Bearish.Portfolio_May27 = mean(NASDAQ.Bearish.prices)
NASDAQ.price_May27 = 67.58

NYSE.Bullish.prices = prices_May27[13:15]
NYSE.Bearish.prices = prices_May27[16:18]
NYSE.Bullish.Portfolio_May27 = mean(NYSE.Bullish.prices)
NYSE.Bearish.Portfolio_May27 = mean(NYSE.Bearish.prices)
NYSE.price_May27 = 11631.87

# Compare portfolio returns
(AMEX.Bullish.Portfolio.ret = ((AMEX.Bullish.Portfolio_May27/AMEX.Bullish.Portfolio_May20)-1)*100)
(AMEX.Bearish.Portfolio.ret = ((AMEX.Bearish.Portfolio_May27/AMEX.Bearish.Portfolio_May20)-1)*100)
(AMEX.index.ret = ((AMEX.price_May27/AMEX.price_May20)-1)*100)

save(AMEX.Bullish.Portfolio.ret, file="AMEX_Bullish_Portfolio_ret.Rda")
load("AMEX_Bullish_Portfolio_ret.Rda")
save(AMEX.Bearish.Portfolio.ret, file="AMEX_Bearish_Portfolio_ret.Rda")
load("AMEX_Bearish_Portfolio_ret.Rda")
save(AMEX.index.ret, file="AMEX_index_ret.Rda")
load("AMEX_index_ret.Rda")


(NASDAQ.Bullish.Portfolio.ret = ((NASDAQ.Bullish.Portfolio_May27/NASDAQ.Bullish.Portfolio_May20)-1)*100)
(NASDAQ.Bearish.Portfolio.ret = ((NASDAQ.Bearish.Portfolio_May27/NASDAQ.Bearish.Portfolio_May20)-1)*100)
(NASDAQ.index.ret = ((NASDAQ.price_May27/NASDAQ.price_May20)-1)*100)

save(NASDAQ.Bullish.Portfolio.ret, file="NASDAQ_Bullish_Portfolio_ret.Rda")
load("NASDAQ_Bullish_Portfolio_ret.Rda")
save(NASDAQ.Bearish.Portfolio.ret, file="NASDAQ_Bearish_Portfolio_ret.Rda")
load("NASDAQ_Bearish_Portfolio_ret.Rda")
save(NASDAQ.index.ret, file="NASDAQ_index_ret.Rda")
load("NASDAQ_index_ret.Rda")


(NYSE.Bullish.Portfolio.ret = ((NYSE.Bullish.Portfolio_May27/NYSE.Bullish.Portfolio_May20)-1)*100)
(NYSE.Bearish.Portfolio.ret = ((NYSE.Bearish.Portfolio_May27/NYSE.Bearish.Portfolio_May20)-1)*100)
(NYSE.index.ret = ((NYSE.price_May27/NYSE.price_May20)-1)*100)

save(NYSE.Bullish.Portfolio.ret, file="NYSE_Bullish_Portfolio_ret.Rda")
load("NYSE_Bullish_Portfolio_ret.Rda")
save(NYSE.Bearish.Portfolio.ret, file="NYSE_Bearish_Portfolio_ret.Rda")
load("NYSE_Bearish_Portfolio_ret.Rda")
save(NYSE.index.ret, file="NYSE_index_ret.Rda")
load("NYSE_index_ret.Rda")



###########################################
# BONUS 1: Scraping our own HTML webpages #
###########################################

# PAGE 1 (BNP Paribas): get numbers #
#-----------------------------------#

url='file:///C:/Users/Albert/Desktop/GIE3-Deliverable/Dorador_Albert.Dou_Yunxuan_Module3_Assessment_Page2.html'
thepage = readLines(url)
(step1 = grep('td',thepage, value = TRUE))
(step2 = str_extract(string = step1, pattern = "-?[:digit:]+(\\.[:digit:]+)?%?"))

# Regex explanation
# Optional minus sign, followed by at least one digit,
# optionally followed by a decimal part containing at least one digit,
# optionally followed by a percentage sign

(step3 = step2[!is.na(step2) & step2!="500"]) #Exclude NAs and the 500 from "S&P500"

# Reconstruct tables
(table1 = data.frame(SP500 = step3[1], Brent = step3[2], DAX = step3[3]))
(table2 = data.frame(SP500 = step3[4], Brent = step3[5], DAX = step3[6]))
(table3 = data.frame(Price_May_20 = step3[c(7,10,13)], 
                     Price_May_27 = step3[c(8,11,14)], 
                     Return = step3[c(9,12,15)]))
rownames(table3) = c("S&P500", "Brent", "DAX")
table3



# PAGE 2 (Yahoo Finance): get (almost) complete tables #
#------------------------------------------------------#

# Get numbers
url='file:///C:/Users/Albert/Desktop/GIE3-Deliverable/Dorador_Albert.Dou_Yunxuan_Module3_Assessment_Page3.html'
thepage = readLines(url)
(step1 = grep('td',thepage, value = TRUE))
(step2 = gsub( '(Hot|Cold)\\s\\d', '', step1))

# Regex explanation
# Remove Hot/Cold_space_digit to avoid confusion with true numbers (e.g. the 1 in "Hot 1" is part of the name)
(numbers = str_extract(string = step2, pattern = "-?[:digit:]+(\\.[:digit:]+)?%?"))
(numbers = numbers[!is.na(numbers)])

# Get tickers
(tickers = str_extract(string = step2, pattern = "[:upper:]+"))

# Regex explanation
# Extract only upper case letters, in groups of at least 1

(tickers = tickers[!is.na(tickers)])

# Reconstruct tables
(table1 = data.frame(Bullish = numbers[1:6], Ticker = tickers[1:6]))
(table2 = data.frame(Bullish = numbers[7:12], Ticker = tickers[7:12]))
(table3 = data.frame(Bullish = numbers[13:18], Ticker = tickers[13:18]))
(table4 = data.frame(AMEX_Bullish = numbers[19], AMEX_Bearish = numbers[20], AMEX_index = numbers[21]))
(table5 = data.frame(NASDAQ_Bullish = numbers[22], NASDAQ_Bearish = numbers[23], NASDAQ_index = numbers[24]))
(table6 = data.frame(NYSE_Bullish = numbers[25], NYSE_Bearish = numbers[26], NYSE_index = numbers[27]))




###########################################
# BONUS 2: Stock recommendations for June #
###########################################


# (1) Code to get the stock recommendations #
#-------------------------------------------#

library(compiler)
enableJIT(3)
setCompilerOptions(suppressAll = TRUE)

library(twitteR)
# key <- "XXXX"          
# secret <-  "XXXX"   
# secrettk <-  "XXXX"   
# mytoken <-  "XXXX"    

# For safety reasons, we don't disclose the value of the parameters below
# and assume the user has loaded them already
setup_twitter_oauth(key, secret, mytoken, secrettk)


# A general function to extract the sentiment of any stock provided a ticker

stock.bullish = function(ticker, from, to, pos, neg, num.tweets=1e3, min.num.tweets = 10){
  require(twitteR)
  score.sentiment = function(sentences, pos.words, neg.words, .progress='none'){
    require(plyr)
    require(stringr)
    scores = laply(sentences, function(sentence, pos.words, neg.words) {
      sentence = gsub('[[:punct:]]', '', sentence)
      sentence = gsub('[[:cntrl:]]', '', sentence)
      sentence = gsub('\\d+', '', sentence)
      sentence = tolower(sentence)
      word.list = str_split(sentence, '\\s+')
      words = unlist(word.list)
      pos.matches = match(words, pos.words)
      neg.matches = match(words, neg.words)
      pos.matches = !is.na(pos.matches)
      neg.matches = !is.na(neg.matches)
      score = sum(pos.matches) - sum(neg.matches)
      return(score)
    }, pos.words, neg.words, .progress=.progress )
    scores.df = data.frame(score=scores, text=sentences)
    return(scores.df)
  }
  tweets = suppressWarnings(searchTwitter(ticker, n=num.tweets,
                                          since=from, until=to, lang="en"))  # I have my own warning
  
  true.num.tweets = ifelse(length(tweets)==0, 0, nrow(twListToDF(tweets)))
  
  if (true.num.tweets < min.num.tweets){
    clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
    return(cat("Could only extract", true.num.tweets, "tweets for", clean.ticker, 
               "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
  }else{
    tweets.text = sapply(tweets, function(x) x$getText())
    # Replace @UserName
    tweets.text = gsub("@\\w+", "", tweets.text)
    # Remove punctuation
    tweets.text = gsub("[[:punct:]]", "", tweets.text)
    # Remove links
    tweets.text = gsub("http\\w+", "", tweets.text)
    # Remove tabs
    tweets.text = gsub("[ |\t]{2,}", "", tweets.text)
    # remove codes that are neither characters nor digits
    tweets.text=  gsub( '[^A-z0-9_]', ' ', tweets.text)
    # Set characters to lowercase
    tweets.text = tolower(tweets.text)
    # Replace blank space (rt)
    tweets.text = gsub("rt", "", tweets.text)
    # Remove blank spaces at the beginning
    tweets.text = gsub("^ ", "", tweets.text)
    # Remove blank spaces at the end
    tweets.text = gsub(" $", "", tweets.text)
    
    stock.score = score.sentiment(tweets.text, pos, neg, .progress='none')
    
    non.neutral.tweets = nrow(stock.score[stock.score[,1]!=0, ])
    
    if(non.neutral.tweets < min.num.tweets){
      clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
      return(cat("Could only extract", non.neutral.tweets, "non-neutral tweets for", clean.ticker, 
                 "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
    }else{
      return(nrow(stock.score[stock.score[,1]>0,])/non.neutral.tweets)
    } 
  }
}

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")

ReapeR = function(market, pos, neg, TopCap, n.hot=3, n.cold=3,
                  from = as.character(Sys.Date()-3), to = as.character(Sys.Date()), 
                  num.tweets = 50, min.num.tweets = 10){
  require(TTR)
  stock.info = stockSymbols(market)
  tickers = stock.info[, 1]
  if (TopCap == "all"){
    n = length(tickers)
  }else{
    stock.info$MarketCap = as.double(
      sub("\\$(\\d+(\\.\\d+)?)[A-Z]?", "\\1", stock.info$MarketCap)) * 
      ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "M", 1e6,
             ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "B", 1e9, 1.0)) 
    stock.sort.ind = order(stock.info$MarketCap,na.last = NA,decreasing = TRUE)
    tickers = tickers[stock.sort.ind]
    n = TopCap
    tickers = tickers[1:n]
  }
  bullish = numeric(n)
  for(i in 1:n){
    aux = stock.bullish(paste0("#",tickers[i]), from, to, pos, neg, num.tweets, min.num.tweets)
    bullish[i] = ifelse(is.numeric(aux),aux,-1)
  }
  mask = (bullish>=0)
  bullish.clean = bullish[mask]
  n = length(bullish.clean)
  
  if(n < (n.hot+n.cold)){
    return(cat("\nRESULT:\nOnly enough non-neutral tweets for", n,
               "stocks, and you requested",n.hot,"hot stocks and",
               n.cold,"cold stocks, making a total of",(n.hot+n.cold),"stocks"))
  }
  
  tickers.clean = tickers[mask]
  
  nthmax = 1:n.hot
  h_and_h.ind = sapply(sort(bullish.clean, index.return=TRUE), '[', length(bullish.clean)-nthmax+1)
  hot = h_and_h.ind[,1]
  hot.ind = h_and_h.ind[,2]
  hot.stocks = tickers.clean[hot.ind]
  
  nthmin = 1:n.cold
  c_and_c.ind = sapply(sort(bullish.clean, index.return=TRUE, decreasing=TRUE), '[', length(bullish.clean)-nthmin+1)
  cold = c_and_c.ind[,1]
  cold.ind = c_and_c.ind[,2]
  cold.stocks = tickers.clean[cold.ind]
  
  return(list(bullish.sentiment = bullish,
              hottest.stocks = hot.stocks,
              hottest.sentiment = hot,
              coldest.stocks = cold.stocks,
              coldest.sentiment = cold))
}

system.time({
  NYSE.200 = ReapeR(market="NYSE",from='2017-05-01',to='2017-05-26',pos=pos,neg=neg,
                    n.hot=3,n.cold=3,TopCap=200,num.tweets=100,min.num.tweets=50)
}) #80 min
NYSE.200
save(NYSE.200, file="NYSE_200_May26_21-23h.Rda")

load("NYSE_200_May26_21-23h.Rda")

#============================================================================================


# (2) Stock recommendations #
#---------------------------#


# 2.a Top 3 Hottest: buy them! 
#-----------------------------
# 1.AON
# 2.MET
# 3.V

# 2.b Top 3 Coldest: sell them!
#------------------------------
# 1.HDB
# 2.BUD
# 3.FDX