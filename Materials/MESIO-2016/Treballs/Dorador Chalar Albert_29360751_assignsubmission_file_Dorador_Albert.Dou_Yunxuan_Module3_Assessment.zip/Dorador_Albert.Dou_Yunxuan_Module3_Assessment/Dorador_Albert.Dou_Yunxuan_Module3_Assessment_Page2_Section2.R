#-----------------------#
# Section 2: Get tweets #
#-----------------------#
today = Sys.Date()
weekb4 = today-7
no.of.tweets = 1e4 #let's get as many tweets as possible for each stock (% only matter)

stocksDF = data.frame()
true.num.tweets = integer(m)
for (i in 1:m){
  search.string = stocks[i]
  auxDF = twListToDF(searchTwitter(search.string, n=no.of.tweets,
                                   since=as.character(weekb4), until=as.character(today), lang="en"))
  true.num.tweets[i] = nrow(auxDF)
  stocksDF = rbind(stocksDF, auxDF)
}
true.num.tweets
colnames(stocksDF)
stocksDF[1,1]