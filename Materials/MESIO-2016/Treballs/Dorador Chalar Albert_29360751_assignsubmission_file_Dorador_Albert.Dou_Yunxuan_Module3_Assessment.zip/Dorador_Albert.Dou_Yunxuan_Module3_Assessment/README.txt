This zipped folder contains:

1) The report, in form of a website (composed of 3 webpages: ...Page1, ...Page2, ...Page3)

2) All the R scripts we have created for this report. The complete script is named ...FULL.R

3) All the files (pictures, graphs, etc) that the website displays

4) The relevant data saved (tweets, stock prices, etc) needed to reproduce the code


Finally, probably the most comfortable way of checking our work done is to use the website-report and click on the relevant links provided there.