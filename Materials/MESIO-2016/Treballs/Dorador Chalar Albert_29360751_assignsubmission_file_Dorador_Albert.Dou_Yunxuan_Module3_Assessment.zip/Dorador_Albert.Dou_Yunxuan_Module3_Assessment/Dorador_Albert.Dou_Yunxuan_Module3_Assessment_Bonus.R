#########################################
# Bonus: Stock recommendations for June #
#########################################


# (1) Code to get the stock recommendations #
#-------------------------------------------#

library(compiler)
enableJIT(3)
setCompilerOptions(suppressAll = TRUE)

library(twitteR)
# key <- "XXXX"          
# secret <-  "XXXX"   
# secrettk <-  "XXXX"   
# mytoken <-  "XXXX"    

# For safety reasons, we don't disclose the value of the parameters below
# and assume the user has loaded them already
setup_twitter_oauth(key, secret, mytoken, secrettk)


# A general function to extract the sentiment of any stock provided a ticker

stock.bullish = function(ticker, from, to, pos, neg, num.tweets=1e3, min.num.tweets = 10){
  require(twitteR)
  score.sentiment = function(sentences, pos.words, neg.words, .progress='none'){
    require(plyr)
    require(stringr)
    scores = laply(sentences, function(sentence, pos.words, neg.words) {
      sentence = gsub('[[:punct:]]', '', sentence)
      sentence = gsub('[[:cntrl:]]', '', sentence)
      sentence = gsub('\\d+', '', sentence)
      sentence = tolower(sentence)
      word.list = str_split(sentence, '\\s+')
      words = unlist(word.list)
      pos.matches = match(words, pos.words)
      neg.matches = match(words, neg.words)
      pos.matches = !is.na(pos.matches)
      neg.matches = !is.na(neg.matches)
      score = sum(pos.matches) - sum(neg.matches)
      return(score)
    }, pos.words, neg.words, .progress=.progress )
    scores.df = data.frame(score=scores, text=sentences)
    return(scores.df)
  }
  tweets = suppressWarnings(searchTwitter(ticker, n=num.tweets,
                                          since=from, until=to, lang="en"))  # I have my own warning
  
  true.num.tweets = ifelse(length(tweets)==0, 0, nrow(twListToDF(tweets)))
  
  if (true.num.tweets < min.num.tweets){
    clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
    return(cat("Could only extract", true.num.tweets, "tweets for", clean.ticker, 
               "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
  }else{
    tweets.text = sapply(tweets, function(x) x$getText())
    # Replace @UserName
    tweets.text = gsub("@\\w+", "", tweets.text)
    # Remove punctuation
    tweets.text = gsub("[[:punct:]]", "", tweets.text)
    # Remove links
    tweets.text = gsub("http\\w+", "", tweets.text)
    # Remove tabs
    tweets.text = gsub("[ |\t]{2,}", "", tweets.text)
    # remove codes that are neither characters nor digits
    tweets.text=  gsub( '[^A-z0-9_]', ' ', tweets.text)
    # Set characters to lowercase
    tweets.text = tolower(tweets.text)
    # Replace blank space (rt)
    tweets.text = gsub("rt", "", tweets.text)
    # Remove blank spaces at the beginning
    tweets.text = gsub("^ ", "", tweets.text)
    # Remove blank spaces at the end
    tweets.text = gsub(" $", "", tweets.text)
    
    stock.score = score.sentiment(tweets.text, pos, neg, .progress='none')
    
    non.neutral.tweets = nrow(stock.score[stock.score[,1]!=0, ])
    
    if(non.neutral.tweets < min.num.tweets){
      clean.ticker = gsub("#",replacement = "",x = ticker)  # Regex to remove hashtag
      return(cat("Could only extract", non.neutral.tweets, "non-neutral tweets for", clean.ticker, 
                 "stock","which is less than the requested minimum of", min.num.tweets,"\n"))
    }else{
      return(nrow(stock.score[stock.score[,1]>0,])/non.neutral.tweets)
    } 
  }
}

pos = readLines("Positive-Words_bis.txt")
neg = readLines("Negative-Words_bis.txt")

ReapeR = function(market, pos, neg, TopCap, n.hot=3, n.cold=3,
                  from = as.character(Sys.Date()-3), to = as.character(Sys.Date()), 
                  num.tweets = 50, min.num.tweets = 10){
  require(TTR)
  stock.info = stockSymbols(market)
  tickers = stock.info[, 1]
  if (TopCap == "all"){
    n = length(tickers)
  }else{
    stock.info$MarketCap = as.double(
      sub("\\$(\\d+(\\.\\d+)?)[A-Z]?", "\\1", stock.info$MarketCap)) * 
      ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "M", 1e6,
             ifelse(gsub("[^A-Z]", "", stock.info$MarketCap) == "B", 1e9, 1.0)) 
    stock.sort.ind = order(stock.info$MarketCap,na.last = NA,decreasing = TRUE)
    tickers = tickers[stock.sort.ind]
    n = TopCap
    tickers = tickers[1:n]
  }
  bullish = numeric(n)
  for(i in 1:n){
    aux = stock.bullish(paste0("#",tickers[i]), from, to, pos, neg, num.tweets, min.num.tweets)
    bullish[i] = ifelse(is.numeric(aux),aux,-1)
  }
  mask = (bullish>=0)
  bullish.clean = bullish[mask]
  n = length(bullish.clean)
  
  if(n < (n.hot+n.cold)){
    return(cat("\nRESULT:\nOnly enough non-neutral tweets for", n,
               "stocks, and you requested",n.hot,"hot stocks and",
               n.cold,"cold stocks, making a total of",(n.hot+n.cold),"stocks"))
  }
  
  tickers.clean = tickers[mask]
  
  nthmax = 1:n.hot
  h_and_h.ind = sapply(sort(bullish.clean, index.return=TRUE), '[', length(bullish.clean)-nthmax+1)
  hot = h_and_h.ind[,1]
  hot.ind = h_and_h.ind[,2]
  hot.stocks = tickers.clean[hot.ind]
  
  nthmin = 1:n.cold
  c_and_c.ind = sapply(sort(bullish.clean, index.return=TRUE, decreasing=TRUE), '[', length(bullish.clean)-nthmin+1)
  cold = c_and_c.ind[,1]
  cold.ind = c_and_c.ind[,2]
  cold.stocks = tickers.clean[cold.ind]
  
  return(list(bullish.sentiment = bullish,
              hottest.stocks = hot.stocks,
              hottest.sentiment = hot,
              coldest.stocks = cold.stocks,
              coldest.sentiment = cold))
}

system.time({
  NYSE.200 = ReapeR(market="NYSE",from='2017-05-01',to='2017-05-26',pos=pos,neg=neg,
                    n.hot=3,n.cold=3,TopCap=200,num.tweets=100,min.num.tweets=50)
}) #80 min
NYSE.200
save(NYSE.200, file="NYSE_200_May26_21-23h.Rda")

load("NYSE_200_May26_21-23h.Rda")

#============================================================================================


# (2) Stock recommendations #
#---------------------------#


# 2.a Top 3 Hottest: buy them! 
#-----------------------------
# 1.AON
# 2.MET
# 3.V

# 2.b Top 3 Coldest: sell them!
#------------------------------
# 1.HDB
# 2.BUD
# 3.FDX