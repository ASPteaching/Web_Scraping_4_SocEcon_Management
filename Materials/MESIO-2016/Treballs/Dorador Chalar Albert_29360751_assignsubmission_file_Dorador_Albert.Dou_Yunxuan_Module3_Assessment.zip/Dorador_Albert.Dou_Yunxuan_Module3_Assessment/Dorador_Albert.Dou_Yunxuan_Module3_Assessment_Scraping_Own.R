##################################
# Scraping our own HTML webpages #
##################################

# PAGE 1 (BNP Paribas): get numbers #
#-----------------------------------#

# Type the correct file path in your case down below
url='file:///C:/Users/Albert/Desktop/GIE3-Deliverable/Dorador_Albert.Dou_Yunxuan_Module3_Assessment_Page2.html'
thepage = readLines(url)
(step1 = grep('td',thepage, value = TRUE))
(step2 = str_extract(string = step1, pattern = "-?[:digit:]+(\\.[:digit:]+)?%?"))

# Regex explanation
# Optional minus sign, followed by at least one digit,
# optionally followed by a decimal part containing at least one digit,
# optionally followed by a percentage sign

(step3 = step2[!is.na(step2) & step2!="500"]) #Exclude NAs and the 500 from "S&P500"

# Reconstruct tables
(table1 = data.frame(SP500 = step3[1], Brent = step3[2], DAX = step3[3]))
(table2 = data.frame(SP500 = step3[4], Brent = step3[5], DAX = step3[6]))
(table3 = data.frame(Price_May_20 = step3[c(7,10,13)], 
                     Price_May_27 = step3[c(8,11,14)], 
                     Return = step3[c(9,12,15)]))
rownames(table3) = c("S&P500", "Brent", "DAX")
table3



# PAGE 2 (Yahoo Finance): get (almost) complete tables #
#------------------------------------------------------#

# Get numbers
# Type the correct file path in your case down below
url='file:///C:/Users/Albert/Desktop/GIE3-Deliverable/Dorador_Albert.Dou_Yunxuan_Module3_Assessment_Page3.html'
thepage = readLines(url)
(step1 = grep('td',thepage, value = TRUE))
(step2 = gsub( '(Hot|Cold)\\s\\d', '', step1))

# Regex explanation
# Remove Hot/Cold_space_digit to avoid confusion with true numbers (e.g. the 1 in "Hot 1" is part of the name)
(numbers = str_extract(string = step2, pattern = "-?[:digit:]+(\\.[:digit:]+)?%?"))
(numbers = numbers[!is.na(numbers)])

# Get tickers
(tickers = str_extract(string = step2, pattern = "[:upper:]+"))

# Regex explanation
# Extract only upper case letters, in groups of at least 1

(tickers = tickers[!is.na(tickers)])

# Reconstruct tables
(table1 = data.frame(Bullish = numbers[1:6], Ticker = tickers[1:6]))
(table2 = data.frame(Bullish = numbers[7:12], Ticker = tickers[7:12]))
(table3 = data.frame(Bullish = numbers[13:18], Ticker = tickers[13:18]))
(table4 = data.frame(AMEX_Bullish = numbers[19], AMEX_Bearish = numbers[20], AMEX_index = numbers[21]))
(table5 = data.frame(NASDAQ_Bullish = numbers[22], NASDAQ_Bearish = numbers[23], NASDAQ_index = numbers[24]))
(table6 = data.frame(NYSE_Bullish = numbers[25], NYSE_Bearish = numbers[26], NYSE_index = numbers[27]))
