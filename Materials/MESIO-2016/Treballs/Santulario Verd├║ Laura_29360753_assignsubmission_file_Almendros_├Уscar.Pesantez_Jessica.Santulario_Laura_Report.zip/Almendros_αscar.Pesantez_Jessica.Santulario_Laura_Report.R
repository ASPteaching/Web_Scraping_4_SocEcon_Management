## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('./dibujo1.jpg')

## ----echo=FALSE, message=FALSE, warning=FALSE----------------------------
# install.packages("stringr")
# install.packages("XML")
# install.packages("bitops")
# install.packages("RCurl")
# install.packages("magrittr")
# install.packages("rvest")
# install.packages("ggplot2")
# install.packages("ggmap")
library(stringr)
library(XML)
library(bitops)
library(RCurl)
library(magrittr)
library(rvest)
library(ggplot2)
library(ggmap)

## ------------------------------------------------------------------------
# Sacar los datos de la p�gina web:
pagina <- "http://elpais.com/elpais/2016/11/23/estilo/1479921816_495721.html"

## ------------------------------------------------------------------------
# Leer los datos:
contenido <- read_html(pagina) #Lee la p�gina web entera

## ------------------------------------------------------------------------
selector <- html_nodes(contenido,css = "#cuerpo_noticia") 
txt <- html_text(selector) #Tiene todo el contenido de la noticia en texto

## ------------------------------------------------------------------------
tres_estrellas <- substr(txt, gregexpr("tres estrellas", txt)[[1]][2] + 
                          attr(gregexpr("tres estrellas", txt)[[1]], "match.length") [2],
                        gregexpr("Dos estrellas Michelin", txt)[[1]][1] - 1)

lineas_tres_estrellas <- unlist(strsplit(tres_estrellas, split="\n- "))
lineas_tres_estrellas <- lineas_tres_estrellas[-1]

dos_estrellas <- substr(txt, gregexpr("Dos estrellas Michelin", txt)[[1]][1] + 
                          attr(gregexpr("Dos estrellas Michelin", txt)[[1]], "match.length") [1], gregexpr("Una estrella Michelin", txt)[[1]][1] - 1)

lineas_dos_estrellas <- unlist(strsplit(dos_estrellas, split="\n- "))
lineas_dos_estrellas <- lineas_dos_estrellas[-1]

una_estrella <- substr(txt, gregexpr("Una estrella Michelin", txt)[[1]][1] + 
                          attr(gregexpr("Una estrella Michelin", txt)[[1]], "match.length") [1], nchar(txt))

lineas_una_estrella <- unlist(strsplit(una_estrella, split="\n- "))
lineas_una_estrella <- lineas_una_estrella[-1]


## ------------------------------------------------------------------------
clase <- list(lineas_tres_estrellas, lineas_dos_estrellas, lineas_una_estrella)

construccion_tabla <- function(index){
  tabla <- array(NA, dim = c(length(clase[[index]]), 3))
  provincia <- NA
  nombre <- NA
  chef <- NA
  posicion_prov <- NA
  for (k in 1:length(clase[[index]])){
    nombre[k] <- substr(clase[[index]][k], 1, gregexpr(",",clase[[index]][k])[[1]][1] -1)
    nombre <- cbind(nombre[1:k])
    
    if(regexpr(", de", clase[[index]][k])[1] == -1){
      chef[k] <- nombre[k]
    } else {
      chef[k] <- substr(clase[[index]][k], regexpr(", de", clase[[index]][k])[1] + 5,
    regexpr(", en", clase[[index]][k][1]) - 1)
    chef <- cbind(chef[1:k])
    }
      
    
    if(length(grep("\\(", clase[[index]][k])) != 0){
      posicion_prov[k] <- gregexpr("\\(",clase[[index]][k])[[1]][1] + 1
    } else {
      posicion_prov[k] <- gregexpr("en",clase[[index]][k])[[1]][1] +  attr(gregexpr("en",clase[[index]][k])[[1]], "match.length")
    }
    
    provincia[k] <- str_trim(str_replace_all(substr(clase[[index]][k], posicion_prov[k], 
                               nchar(clase[[index]][k])), pattern = "[.)\n]", ""), "both")
    provincia <- cbind(provincia[1:k])
    
  }
  tabla <<- data.frame(nombre, chef, provincia)
  names(tabla) <<- c("Nombre Restaurante", "Cocineros", "Provincia")
  
}

# Tabla de tres estrellas Michelin
construccion_tabla(1)
tabla1 <- tabla

# Tabla de dos estrellas Michelin
construccion_tabla(2)
tabla2 <- tabla

# Tabla de una estrella Michelin
construccion_tabla(3)
tabla3 <- tabla

#Presentaci�n de las tablas 
tabla_1 <- knitr::kable(tabla1, format = "markdown",
                       caption = "Restaurante tres estrellas Michelin")

tabla_2 <- knitr::kable(tabla2, format = "markdown",
                       caption = "Restaurante dos estrellas Michelin")

tabla_3 <- knitr::kable(tabla3, format = "markdown",
                       caption = "Restaurante una estrella Michelin")

## ------------------------------------------------------------------------
#Frecuencia de provincias con restaurantes de estrellas Michel�n
cont_ccaa <- function(tab){
  contador <- array(NA, dim = length(tab))
  for (j in 1:length(tab[,3])) {
    if ((tab[j,3] == "Barcelona" ) || (tab[j,3] == "Tarragona") || (tab[j,3] == "Lleida") || (tab[j,3] == "Girona")) {
    contador[j] <- "Catalunya"
  } else if ((tab[j,3] == "Gipuzkoa") || (tab[j,3] == "Bizkaia")) {
    contador[j] <-  "Pa�s Vasco"
  } else if ((tab[j,3] == "Valencia") || (tab[j,3] == "Castell�n") || (tab[j,3] == "Alicante")) {
    contador[j] <-  "Comunitat Valenciana"
  } else if (tab[j,3] == "Madrid") {
    contador[j] <-  "Comunidad de Madrid"
  } else if (tab[j,3] == "Cantabria") {
    contador[j] <-  "Cantabria"
  } else if ((tab[j,3] == "Madeira") || (tab[j,3] == "Porto") || (tab[j,3] == "Portugal")) {
    contador[j] <-  "Portugal"
  } else if ((tab[j,3] == "Mallorca") || (tab[j,3] == "Palma de Mallorca")) {
    contador[j] <- "Illes Ballears"
  } else if ((tab[j,3] == "Andaluc�a")) {
    contador[j] <- "Andaluc�a"
  } else {
    contador[j] <- "Castilla y Le�n"

  }
    
  }
  cont <<- contador
}

# 
cont_ccaa(tabla1)
cont_tabla1 <- cont

cont_ccaa(tabla2)
cont_tabla2 <- cont

cont_ccaa(tabla3)
cont_tabla3 <- cont

vector <- c(cont_tabla1, cont_tabla2, cont_tabla3)

## ------------------------------------------------------------------------
x<-read.csv("provincias.csv", header=T)
rownames(x)<-x$Provincia
x$Provincia<-NULL
x <- as.data.frame(x)

## ----message=FALSE-------------------------------------------------------
mapgilbert <- get_map(location = c(lon = mean(x$Longitud), lat =mean(x$Latitud)), zoom =5,
                      maptype = "satellite", scale = 1)

## ----warning=FALSE-------------------------------------------------------
ggmap(mapgilbert) +
  geom_point(data = x, aes(x = x$Longitud, y = x$Latitud, fill = "red", alpha = 0.4), size = 3, shape = 21) +
  guides(fill=FALSE, alpha=FALSE, size=FALSE)

## ------------------------------------------------------------------------
tabla_1
tabla_2
tabla_3  

## ------------------------------------------------------------------------
par(las = 2, font.lab = 2)
barplot(table(vector), xlab = "", ylab = "Frecuencia por CCAA", main = "Nuevas Estrellas Michelin \n en 2016", ylim = c(0,10), col = hsv(.5, .5, .5))

