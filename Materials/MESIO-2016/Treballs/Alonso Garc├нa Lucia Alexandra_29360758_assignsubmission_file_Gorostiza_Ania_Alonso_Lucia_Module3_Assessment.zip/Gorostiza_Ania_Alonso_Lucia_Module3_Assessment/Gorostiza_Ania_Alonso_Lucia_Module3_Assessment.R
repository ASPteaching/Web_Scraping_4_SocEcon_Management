# cargar librerias
library(httr)
library(twitteR)
library(tm)
library(wordcloud)

setwd("E:/GESTION/3-WEB SCRAPING")

setup_twitter_oauth('aZD4YegsooZfBaP66XElzdS61', 'mx7Z4MA7IEiTISl3ncMmCBMz0zVyc9ZifZtINm7qb4XLj0tVIE', '478952918-rvsnR5d3SpPZYtDqA0oumFlX2ZBERGXMDPr7N1CV', '15ZTTIKwW9bMPSnnowjPQKWnlSfqsQMj7qqJmLSRYKwrU')


## recolectamos tweets 
pod <- userTimeline("ahorapodemos", 2000, includeRts = T)
pp <- userTimeline("PPopular", 2000, includeRts = T)
psoe <- userTimeline("PSOE", 2000, includeRts = T)
cs <- userTimeline("ciudadanosCs", 2000, includeRts = T)


## volcamos la informacion de los tweets a un data frame
d.pod <- twListToDF(pod)
d.pp <- twListToDF(pp)
d.psoe <- twListToDF(psoe)
d.cs <- twListToDF(cs)

## guardamos los dataframes para futuros an�lisis
save(d.pod, file = "podemos.Rdata")
save(d.pp, file = "pp.Rdata")
save(d.psoe, file = "psoe.RData")
save(d.cs, file = "ciudadanos.RData")

## texto de los tweets
t.pod <- d.pod$text
t.pp <- d.pp$text
t.psoe <- d.psoe$text
t.cs <- d.cs$text


## FUNCIONES PARA LIMPIAR DATOS

# Tildes y �
tildes <- function(x){
  x1 <- gsub("�", "axx", x)
  x1 <- gsub("�", "exx", x1)
  x1 <- gsub("�", "ixx", x1)
  x1 <- gsub("�", "oxx", x1)
  x1 <- gsub("�", "uxx", x1)
  x1 <- gsub("�", "ny", x1)
  x1 <- sub("�", "AXX", x1)
  x1 <- gsub("�", "EXX", x1)
  x1 <- gsub("�", "IXX", x1)
  x1 <- gsub("�", "OXX", x1)
  x1 <- gsub("�", "UXX", x1)
  x1 <- gsub("�", "NY", x1)
  return(x1)
  
}
invtildes <- function(x){
  x1 <- gsub("axx", "�", x)
  x1 <- gsub("exx", "�", x1)
  x1 <- gsub("ixx", "�", x1)
  x1 <- gsub("oxx", "�", x1)
  x1 <- gsub("uxx", "�", x1)
  x1 <- gsub("ny", "�", x1)
  return(x1)
  
}
# Limpieza
limpiar <- function(x){
  x1 <- tildes(x)
  # remove @UserName
  x1 <- gsub("@\\w+", " ", x1)
  # remueve simbolos de puntuaci�n
  x1 <- gsub("[[:punct:]]", "", x1)
  # remueve links
  x1 <- gsub("http\\w+", " ", x1)
  # Remove tabs
  x1 <- gsub("[ |\t]{2,}", "", x1)
  # remove codes that are neither characters nor digits
  x1 <- gsub("[^A-z0-9 ]", "", x1)
  # Set characters to lowercase
  x1 <- tolower(x1)
  # Replace blank space ("rt")
  x1 <- gsub("rt", "", x1)
  # Remove blank spaces at the beginning
  x1 <- gsub("^ ", "", x1)
  # Remove blank spaces at the end
  x1 <- gsub(" $", "", x1)
  return(x1)
}

## Palabras vac�as
# Lista de palabras vac�as externa
sw <- readLines("stopwords.es.txt",encoding="ASCII")
sw <- tildes(sw)
palvacias <- function(x){
  x1 <-  tm_map(x, removeWords, tildes(stopwords("spanish")))
  x1 <- tm_map(x1, removeWords, sw)
  # remove espacios en blanco extras
  x1 <- tm_map(x1, stripWhitespace)
  return(x1)
}

## CONTEO DE PALABRAS
conteo <- function(x){
  tdm <- TermDocumentMatrix(x)
  m <- as.matrix(tdm)
  # conteo de palabras en orden decreciente
  wf <- sort(rowSums(m),decreasing=TRUE)
  # crea un data frame con las palabras y sus frecuencias
  dm <- data.frame(word = names(wf), freq=wf)
  # arreglamos tildes y �
  dm$word <- invtildes(dm$word)
  return(dm)
}


## PODEMOS
## =======

## Limpieza de datos:
t2.pod <- limpiar(t.pod)
head(t2.pod)

## Corpus
c.pod <- Corpus(VectorSource(t2.pod))
#inspect(c.pod)

## Palabras vac�as
c.pod <- palvacias(c.pod)
#inspect(c.pod)

## Conteo de palabras
dm.pod <- conteo(c.pod)

# grafica la nube de palabras (wordcloud)
wordcloud(dm.pod$word, dm.pod$freq, random.order=FALSE, colors=brewer.pal(8, "Dark2"))

## PP
## =======

## Limpieza de datos:
t2.pp <- limpiar(t.pp)
head(t2.pp)

## Corpus
c.pp <- Corpus(VectorSource(t2.pp))
inspect(c.pod)

## Palabras vac�as
c.pp <- palvacias(c.pp)
inspect(c.pod)

## Conteo de palabras
dm.pp <- conteo(c.pp)

# grafica la nube de palabras (wordcloud)
wordcloud(dm.pp$word, dm.pp$freq, random.order=FALSE, colors=brewer.pal(8, "Dark2"))

## PSOE
## =======

## Limpieza de datos:
t2.psoe <- limpiar(t.psoe)
head(t2.psoe)

## Corpus
c.psoe <- Corpus(VectorSource(t2.psoe))
#inspect(c.psoe)

## Palabras vac�as
c.psoe <- palvacias(c.psoe)
#inspect(c.psoe)

## Conteo de palabras
dm.psoe <- conteo(c.psoe)

# grafica la nube de palabras (wordcloud)
wordcloud(dm.psoe$word, dm.psoe$freq, random.order=FALSE, colors=brewer.pal(8, "Dark2"))

## CIUDADANOS
## =======

## Limpieza de datos:
t2.cs <- limpiar(t.cs)
head(t2.cs)

## Corpus
c.cs <- Corpus(VectorSource(t2.cs))
#inspect(c.cs)

## Palabras vac�as
c.cs <- palvacias(c.cs)
#inspect(c.cs)

## Conteo de palabras
dm.cs <- conteo(c.cs)

# grafica la nube de palabras (wordcloud)
wordcloud(dm.cs$word, dm.cs$freq, random.order=FALSE, colors=brewer.pal(8, "Dark2"))