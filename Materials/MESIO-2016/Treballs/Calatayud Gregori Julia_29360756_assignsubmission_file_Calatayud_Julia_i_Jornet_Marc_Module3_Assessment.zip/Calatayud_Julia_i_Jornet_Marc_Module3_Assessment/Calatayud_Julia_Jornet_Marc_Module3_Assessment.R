
if (!(require(shiny))) install.packages("shiny", dep=TRUE)
require(shiny)

source("script_treball_marcjornet_juliacalatayud.R")

server <- function(input,output) {
  
  info <- reactive({
    LIST_OF_HEADINGS()
  })
  
  output$news_urls <- renderPrint({
    list_of_news <- LIST_OF_NEWS(info(),input$word_of_interest)
    if (length(list_of_news)>0) {
      for(noticia in list_of_news)
        cat(paste(noticia,"\n"))
    } else {
      cat("There are no news related to",input$word_of_interest)
    }
  })
  
}

ui <- fluidPage(
  titlePanel("Searcher of news of interest in Sport"),
  h4(em("Authors: Julia Calatayud Gregori and Marc Jornet Sanz")),
  br(),
  br(),
  p("Sport is a catalan daily sports newspaper founded in 1979. It writes mainly about 
   Football Club Barcelona and Spanish football."),
  p("This newspaper has an electronic version in http://www.sport.es/es/. Although the news are
    presented in an organized way, it is difficult to know quickly what news are about what you
    are interested on."),
  p("Because of this, our app provides the URL of the news that are interesting for you. In the 
    cell below, you write any character string related to your interest. The app looks for the 
    news that contain in their heading (title or subtitles) this character string. The programming 
    procedure is based on web scrapping in R."),
  p(span("Attention:",style = "color:red"), "The first time this app is open, the program starts 
    downloading all Sport's news, and this process lasts around 30 seconds. After this, you will 
    see on the right hand side all the news from Sport. Once all the news are downloaded, you
    will be able to search the URLs that contain the string in the heading."),
  br(),
  br(),
  sidebarLayout(
    
    sidebarPanel(textInput("word_of_interest","Enter your string of interest",""),
                 img(src="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxEQERAQEA8QFRAQEA8SDhUSERISGBIQFRMWFhYWExoYHygsGBolJxUXITEhJiksLi4uGB82OzMvNyotLi0BCgoKDg0OGhAQGzAlICUvLS0rLy0rLy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tK//AABEIAOEA4QMBEQACEQEDEQH/xAAcAAEAAgMBAQEAAAAAAAAAAAAABAcDBQYBAgj/xABDEAACAQMABQgHBgMGBwAAAAAAAQIDBBEFBhIhMQdBUVNhcYHRExQykaGx8BUicpKTwTRCsiM1Q1LS8RckYnOis8L/xAAbAQEAAgMBAQAAAAAAAAAAAAAAAgQBAwYFB//EADARAQACAQIEBAUEAgMBAAAAAAABAgMEEQUSITETFFGRIjJBUnEGYYGxMzShwfAV/9oADAMBAAIRAxEAPwDjDzH1kAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAxuMkKE5LMYSa6VFsztLXbLjrO02iP5fEk08NYfQ9wTi0T1h4GTJjeGDI3hkyN4AyAAD1LO5cewwxMxEby+50JxWXCaXS4tGdkK5sdp2i0T/LGYbAyGTG8BkbwGRvAADIGN4DI3gMjeAyN4AbgZAAAA3+q2qta/niC2aaf35v8Abz+ZKlJvPR5nEOJ49JG09Z9FtaE1Cs7ZJun6Sa/mlnj2fWOwt0wVq43VcY1Oefm2j9nQR0bQX+DS/JHyNkViOzz5y5J72lgutB21VOM7em0+OI7Oe/GDHh19E6arNSd62lzVzqVaW9ejXpwacqsIOH8rjJpPhwSXQvHeabYq1mNvV6deK6jLitjvO8bTO/16Oj+wLXqIfHzN3h1eb5vN90n2Ba9RD4+Y8Op5vN90j1ftX/gQ/wDLzHh19DzWb7mi0xyeWVdPYp+invw4bt/b0+Oe412wVnsv6bjWqxT1tvH7qm1k1crWVX0U4tqT/s5JN7eeCXb8+/KVS9JrO0uy0PEceqx80dNu7rtUeTd1YxrXbai0moJ4bXa1/t3o3Y8Ez1l4nEOP8szTB7rGsNXbWgtmnQp47Yp5fTjgvBFmMdY7Q5rLrM+Sea1p90t6NoPjQpfkj5GZrEtUZckdrT7tBpvUOzuU36P0c+aUc5z2+XDsNdsFbPQ0vF9TgnpbePSVSa16rVrCWJrapv2Zr9/r3cCpkpNZ6ux4fxPHq69OlvRcehNC287ejKVGDlKCbe/eXKUrNXEanU5a5bRFp7p32Ba9RD4+ZLw6tPms33SfYFr1EPj5jw6nm833SgaQ1Ksaye1bxTaxtLOcd74eBG2Kst+HiepxfLZX2sGoc7OtRrUW50fTUtpYy4rbWfD9lx6NFsU1tHo6DBxuNRgvjydLbTtP8LQWgLXqIfHzLPh1cx5rN90n2Ba9RD4+Y8Op5vN90n2Ba9RD4+Y8Op5rN90n2Ba9RD4+Y8Op5vN90qu5X7SnRrWsacFGLpVG0unaiv2K+eIjbZ1P6cyWvGTmnft/24AruoAAGW1oupOEFxnKMVz4y8ZCGS/JSbekP0Xq7ouFrb06UIpYitrtlg9CleWNnzHVai2fLN7S2ZNXcjpLlDsaFR03KblF4ezFtGmc9YnZ62DguqzU56x0/LPo7X2wrNRVXZk9yU1jL6EuL9wjPSUM3B9Xijea+yBpfTaqaTsrenJOMXtyaeU96x3r94mu94m8RH7N+n0k10eXLaP2h2xaeKw3dzGlCVSfsxWWYmdkqVm9uWO7XaL1mtLmWxRrwlP/ACprJGMlZ7SsZtFnwxzZKzDbk1VrNMWFOo6E6kVL0daHFJ+39xce2S8MrnZC9d9pb8OW9ItFZ7w2SJtD0DHTrxllRlFtccSTwY3hmYmO7IZYa/Tmi6d1RnRqJNSi0s8zwRtXmjZu0+e2DJF6y90FHZt6UcNOMXFp4bTjJpp459xjHHwmotzZJn1TybS09XWe0hV9BOtGNXLWJbstNrcvBkJvWJ2Wq6LPbH4la7x6tumTVWG9tY1ac6UvZnFxeNzWedPma4p9hiY3hKlpraLQ8trhShCUmk5RTks8HjejEWjbdm1Ji0xDPGSe9cCSD0D49LHONpZXFZRjeGeWfRUnLS/+Ytf+zU/qRW1H0db+me2T+FdFZ1YAAl6KrKFejOXCNSDeeZZ3szWdpiVfV4/EwWrH1h+k7aspxjOL3SimvFHoxO8PmFqzW0xLKZRaq+1ctK+XVt6cm+O4hOOs91nFrM+L5LTDQ6R5NbGonsKVOXM48F4LGfE1zp6z2ehh47qsc9Z3hzmitU7iy0lbSnJ1KTajCbbeyk0lF9i3Lm7luNPhzS0bvTz8TxarR3rEbW77LWLrk0DTtCVS3qwgsylHCXiiN43jZu094plraeyutR9RLqhc069fZjGnvwm3net2/H18a2LDatt5dHxTjODPg8PHE7ytQtuWRdIewl01aH/ti/2MTOydO/ukmUFX8qus9WnUVpRk4rZ2qjT3vP0+7HuqZ8k77Q6ngHDaZKzmyRv6K8s9M3FKcakK9Tai8ranKS+L+PErxMx2dNl0WDLXltWF96paX9ctaVZ+01if4ljP105PQx25q7vneu03l89sfo3JNURbVYnWjzbaku6UI5+Kl7yMd5Tt1iJSiSCsdYNSbq5v3XioxpbaeXJZwqkpcPFeRVyYptfd0ui4th0+jnFPWZ3/AK2WTbUtiEI5zsxjHPThYLUdnN2neZlklLCy+C3vuDD88ayaTqSurh06tRRdR4UZySTXHcn05PNtaZ3h9G0Gkxxp6Tasc23ovnQP8PR/B+7L+P5YcBqf81vzKeTaFH8pd1Uhf1FCpUitmLxGcorO1LmTKGWZjJOzuuB4ceTSRz1ies93JV7qpUwp1Jy2c7O1JyxnGcZ7l7jXMzL2seHHj+SIhhDaAAPQO81N1+naQjSuIynRy1CW/djj7s82fe2zbjzcnSXNcS4JXPab4ZiJ+sLDs9eLCqk1cRi3wUuPuWSzGak/VzmThWrx96S29rpSjVwqdWEm+CT3vwZOLRKlfDkp81ZTCTWiaTpbVOTx96GKlPsnD70fljubI27NmK21vz090qLyk1zrKJNb0DwBKWFltYXECDb1o157UXmnSk0n/mq7O9rsSljty+hZhE80/httWccbT3n+k8m1Ka5W9FThcq4UX6OpBJvoafP4yfw6UUs8TFt3afpzU0nFOL67uDhBtpJNtvCS3tvsRodHa0RG8r95P9GStrGlCftSzNro2t/n4YL+Gu1er5xxTURn1NrV7OkNrz0a2eZ1n0SjH3Qi/wD6Ix3lO3yxCSSQAPGwKw1619qR27WjSnTk19+U1hpP6aa4buL3oqZc09odRwng1cm2a8xMKtk85ZWdhHSOj9J6B/hqP4F82ejj+WHy7U/5rfmU8m0KK5Uf7wn+CP8AVM8/L88u+4B/px+ZciQe2AAAH1Tg5NRisyk0orpbeEgja0ViZntC9dBaoW/qVKjWpRk9naba35e/n784ecNsu0xRy7S+eaniWadTbJSdmpvuSq2m806tSHZ7XxeSE6aJXcX6j1FY+KIlM1b5PKVnVjW9NOUotNLgt2/fjivAzTBFZ33aNbxrJqack1iIdsWHiomlKqjTaziVTFOH45/dXuznuTI3no2Yq72/HX2SorCSXBcCTWg6drSp29acHiUY5T8UQvPwt2mpFssRKlv+IekOtj7p/wCopRlv6u5/+Do/T/lB0hrde11szuJqPRFteKby0+5mJyWnvKxh4TpMU7xX3dnyRafS27SpLDbcqWefL3+OW/fE3YLxHwvC/UOi2mM9I6dpWmW3KsN1awqx2KkFKL5mvl0GJiJ7pUvak71nZrbLVayoy26drTjLpS+fSQjFWO0LOTXajJHLa8zDcGxUYL27jRhKpN4jBNvyMTO0bpUpN7RWrBoae1RhN4zPam2s4blJvdnmI06xunnry5Jr6JxNqc9oTS0XdXVq29uM5Tjlt5TlLcs/h4f9LNcW+KarmbTzGGuX6dv/AHu6E2Kbh+UzVj1qj6enH+2pLO7+aP0ks9i5kaM2PeN4e3wXX+Xy8lvllSsljOe0pfR3sTvG8P0noH+Go/gXzZ6OP5YfLtT/AJrfmU8m0KK5Uf7wn+CP9Uzz83zy77gH+nH5lyJB7YAAAbXVm6oUbmnUuFJ04POEs793Hsxnhz4M1mInqo8Qx5cuC1MXeV6aM1os7hZp3EO1NpbPfzLuyXq5az2l8/zaDUYZ+OsttSrRksxlFrpTT+RPeFWazHeH05Y4syxs1Gl9Z7S1i5VK0OxRabb6F29nHsNdsta/Vc0+gz552pVwlhrnO+0jQj7FvCWUnuzhre+z63cCt4vPaHvZeE10mjva3W0rN9cpdbT/ADx8y5zR6uX5LejXaxXVN2tdKpBtw3JSi+dELzE1WNJS3jV6Pzojz4fTwyMttXlTnGcJNSi8xa5mP3a8mOuSs1tHSVt6p8o9KpGNO7exUW7a5peP0+/iWqZ47WcXxDgWTFM2w9au8t7unUWYVIy7mm13rmLEWiXg2pas/FGzM5Gd0Nmq0rrFa20XKrWhu5lJNt9Hf2ELZK1WsGizZp2pWVR67a7zvs0qWYUFnvn39n1u35p5cs2/DseF8Grpvjydbf0tvQFzTVtQTqQTVNZTlFYLdJjlcbqqWnLbo2HrlLraf54+ZPmj1aOS3op/T+mHa6X9PGX3ctSa4ODqTz4cH4FPJbbJu6/Q6WNRw2cc99+n52hblDSNKcYyVSGJJPDlFNZ5nv4luLQ5K2K9bTEw+5XdJ7nUp45/vx8xvCPJb0Uvykavxt6zrUHF0qmW9lqWzLtxw4478c7KWam07w7fgmvnLj8K/eOy29B3VNW9JOpBNQ3pyisby3SY5YcfqaW8a3T6yneuUutp/nj5k+aPVo5LeikOU6Sd/Npppwjhp5T+9MoZfnl3vAI20kfmXJEHtAAAAA9TDEpdLSlePCvV/PJ/Mby0W0mG3esez7q6ZuJLDr1PCWPkZm0z3a6aDT07Uj+0KpNyblJtyfFttt97ZharWKxtEPadWUXmMnF9MW0/egWrW0bWjdm9frddV/Un5hr8vi+2PaHjvq3XVf1JeYPL4vtj2hHDcAAAEi3vatPChVnFLglJpe4dmm+DHf5qxP8ACRPTVzJYdepjsePkZm1paa6DT1neKQhVaspvalKUpdMm2/eyK1WlaxtWNnwZSSFfVuuq/qS8w0+XxfbHtD31+t11X9SfmDy+L7Y9oYatWUnmUpSfTJtv4hsrStY2rGzLG9qpJKrVSW5JTluXvCE4MU9eWPaHvr9brqv6k/MMeXxfbHtD5qXdSScZVajT4pzk0+9NhmuHHWd4rHs99erddV/Ul5hjy+L7Y9oe+v1uuq/qT8weXxfbHtDDVqym8ylKT4Zk23jxDZWlaxtWNnwEgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//9k=", height = 180, width = 200)
                ),
    
    mainPanel(strong("News where your string of interest appears in the heading:"),
              p(" "),
              tags$head(tags$style(type="text/css", "
                                                        #loadmessage {
                                                        width: 65%;
                                                        padding: 5px 0px 5px 0px;
                                                        font-weight: bold;
                                                        color: #000000;
                                                        background-color: #CCFF66;
                                                        }
                                     ")
              ), 
              conditionalPanel(condition="$('html').hasClass('shiny-busy')",
                               tags$div("I'm loading the news from Sport...",id="loadmessage"),
                               tags$script(HTML("(function blink() { 
                                  $('#loadmessage').fadeOut(2000).fadeIn(2000, blink); 
                                  })();
                                "))
              ), 
              verbatimTextOutput("news_urls"))
  )
)

shinyApp(ui = ui, server = server)