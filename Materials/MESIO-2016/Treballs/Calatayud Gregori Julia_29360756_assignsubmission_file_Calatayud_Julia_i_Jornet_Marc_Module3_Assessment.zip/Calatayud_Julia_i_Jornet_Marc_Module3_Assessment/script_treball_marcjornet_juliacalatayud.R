# Given any string, we search from the newspaper Sport any principal new (not advertisements,
# not opinion articles, not news from another newspaper) such that its title or
# subtitles (i.e., heading of the new) contain that string (not taking into account lower case
# letters or capital letters, for example neYmAR and NEYMar does not make any difference from 
# Neymar).
# This script gives the url of the news containing the chosen string by the user in their heading.
# This allows knowing the url of your interest directly, without reading all the newspaper Sport.

LIST_OF_HEADINGS <- function() { 
  # Input: none.
  # Output: urls = list of all urls corresponding to news in the Sport;
  #         headers_news = list of all headings of the news in the Sport;
  # Goal: to download all the information we need from Sport.
  
  if (!(require(stringr))) install.packages("stringr", dep=TRUE)
  require(stringr) # for treating string functions
  if (!(require(rvest))) install.packages("rvest", dep=TRUE)
  require(rvest) # for read_html function
  sport <- readLines(con="http://www.sport.es/es/") # list of lines of the html code

  news <- "/es/noticias/" # pattern common to all news in Sport
  lines_news <- grep(news,sport,value=TRUE) # lines in html with that pattern (with the possible news)

  news_another_newspaper <- c()
  for (line in lines_news) {
    if (grepl("http",line) & grepl("sport",line)==F)
      news_another_newspaper <- c(news_another_newspaper,line)
  }
  lines_news <- setdiff(lines_news,news_another_newspaper) # delete news that come from another newspaper (for example, El Peri�dico)

  urls <- c()
  for (new in lines_news){
    beginning <- str_locate(new,"/es/noticias/")[1] # the address of the new starts with /es/noticias/
    possible_endings <- str_locate_all(new,'["]')[[1]][,1] # the address of the new ends with a \"
    ending <- possible_endings[min(which(possible_endings>beginning))]-1 # the first \" after /es/noticias/ indicates the end of the address
    urls <- c(urls,paste(c("http://www.sport.es",substr(new,beginning,ending)),collapse=""))
  }
  urls <- unique(urls) # delete the repeated news that appear in the html code of the Sport

  headers_news <- c()
  for (url in urls){
    inside_new <- read_html(url)
  
    header_new <- inside_new %>% 
    html_nodes('.head') %>% # we used a selector to find out the html code of title and subtitle
    html_text() 
    headers_news <- c(headers_news,tolower(header_new[1])) # title and subtitle of the new plus tabulators
  }
  
  return(list(urls,headers_news))
}
 
LIST_OF_NEWS <- function(info,word_of_interest) { 
  # Input: info = output from the other function (all urls and their heading from Sport);
  #        word_of_interest = string to be searched in info[[2]] (headers) (the string 
  #                           can be written in lowercase, uppercase or mixed as you wish).
  # Output: urls_of_interest: the urls (in info[[1]]) such that their heading (in info[[2]])
  #                           contains word_of_interest.
  # Goal: extract the urls of the news in Sport that contain the string of interest in their heading.
  
  urls <- info[[1]]
  headers_news <- info[[2]]
  word_of_interest <- tolower(word_of_interest)
  urls_of_interest <- c()
  for (i in 1:length(headers_news)) {
    if (grepl(word_of_interest,headers_news[i])) # true if your word of interest is in the string
      urls_of_interest <- c(urls_of_interest,urls[i])
  }
  
  return(urls_of_interest)
}
